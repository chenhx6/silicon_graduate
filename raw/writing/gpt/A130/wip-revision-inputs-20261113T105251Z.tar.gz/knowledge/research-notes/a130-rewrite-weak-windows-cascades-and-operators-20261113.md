---
type: research-note
title: "A130重写研学：弱衰变能窗、缓发级联竞争与双贝塔矩阵元边界"
aliases: [A130 weak windows cascades and double-beta boundaries]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
created_from: "针对博士论文第4.7节弱衰变三子模块微观机制与多体边界的定向研学"
promotion_target: ""
evidence_sources: [dimitriou-2021-beta-delayed-neutron-reference-database, cirigliano-2018-leading-short-range-double-beta, engel-menendez-2017-double-beta-matrix-elements-review, doctoral-r1-g34-zhi-2013-prc-shell-model-half-lives]
tags: [A130, doctoral-foundations, weak-decay, beta-decay, first-forbidden, delayed-neutrons, double-beta, majorana]
---

# 弱衰变能窗、缓发粒子级联与双贝塔矩阵元微观边界

## Research Trigger

在第 4.7 节的体系构建中，弱衰变常被简化为单一的 $Q_\beta$ 能窗积分，或将缓发中子发射几率 $P_n$ 机械等同于 $Q_\beta - S_n$ 能窗大小，亦或将无中微子双贝塔衰变（$0\nu\beta\beta$）核矩阵元与低能单 $\beta$ 淬灭无条件挂钩。本笔记旨在基于国际原子能机构（IAEA）缓发中子基准数据库、手征有效场论短程接触算符与从头算双贝塔矩阵元综述，确立有限 $Q_\beta$ 窗下允许与禁戒跃迁的相空间结构、$\beta$ 馈送后 $\gamma/n$ 统计竞争级联的条件概率分解，以及高动量转移下轻 Majorana 交换 $0\nu\beta\beta$ 矩阵元的真实微观依赖。

## Grounded Evidence

| 依赖与本轮核读 locator | 实际载体和核验 | 支持范围及证据身份 |
|---|---|---|
| [[dimitriou-2021-beta-delayed-neutron-reference-database]]，全书 96 页，Section II PDF pp. 4–11，PDF pp. 18, 24，Section IV PDF pp. 84–85 | `raw/papers/gpt/query/20261108-r3-g52-beta-delayed-particles/dimitriou-2021-iaea-beta-delayed-neutron-database.pdf`；SHA-256 `6cefc692c89eafe3892a4e2870198083a216fe859e4e69bbf590b15112fa5a72` | 缓发中子基准数据库：$P_{1n}$、$P_{2n}$、$P_{\ge 1n}$ 与平均中子多重度 $\langle M_n \rangle$ 的严格操作定义；指出 $Q_{\beta n} = Q_\beta - S_n$ 能窗虽主导但不足以预测 $P_n$（受中间态自旋宇称、离心位垒与 $\Gamma_\gamma$ 强竞争调制，跨闭壳出现突变）。 |
| [[cirigliano-2018-leading-short-range-double-beta]]，全书 6 页，PDF pp. 1–4，Eqs.(1)–(3) | `raw/papers/gpt/query/20261108-r3-t07-weak-renormalization/cirigliano-2018-prl120-202001-arxiv-1802.10097v1.pdf`；SHA-256 `c15e22bdb9c811e986493ff2a0b01f2794c8a33a6493b4ba6d62701525304996` | 手征有效场论下轻 Majorana 中微子交换 $0\nu\beta\beta$：证明核子-核子 $1S_0$ 非微扰强散射要求引入领头阶 $\Delta L = 2$ 短程接触算符（$g_\nu^{NN}$ 项）以保证重整化群自洽；明确其为理论自洽性所需，不表述为数值上支配所有通道。 |
| [[engel-menendez-2017-double-beta-matrix-elements-review]]，全书 35 页，Section 2.1 PDF pp. 4–5，Section 4.3 PDF pp. 17–18 | `raw/papers/gpt/query/20261108-r3-g48-weak-operators/engel-menendez-2017-rpp-0nubb-nme.pdf`；SHA-256 `813111c10bab58d8d0f19ca91833383a8a521a33c0434b276eacd4fead195417` | $0\nu\beta\beta$ 核矩阵元权威综述：特征虚动量转移 $|\mathbf{p}| \sim 100\text{--}200\text{ MeV}/c$（探测 $r \sim 1\text{--}2\text{ fm}$ 短程距离）；配对关联增强矩阵元而初末态四极形变错位压低矩阵元；相空间 $G_{0\nu}$ 与 $g_A$ 约定的对应关系。 |
| [[doctoral-r1-g34-zhi-2013-prc-shell-model-half-lives]]，全书 14 页，Section II.B PDF pp. 2–5，Eq.(4), Eq.(16) | `raw/papers/gpt/query/20261108-foundations-G34/Zhi_2013_PRC_87_025803_SM_halflives_first_forbidden.pdf`；SHA-256 `eaedbd4539854e3d1f0e7860ef7ab9c647d4fa44cd8144b4989ba220ec639333` | 快中子俘获 $r$-过程等待点核大尺度壳模型计算：微分能谱 $d\lambda/dW \propto F(Z, W) p W (W_0 - W)^2 C(W)$；一阶禁戒衰变算符秩与空间对称性依赖（类时轴荷 $\gamma_5$ 增强而类空算符淬灭）。 |

## Provisional Reasoning

1. **有限 $Q_\beta$ 能窗与跃迁强度分布：**
   单体 Ikeda 差和定则 $S_- - S_+ = 3(N-Z)$（已在第2.7节推导）是在全 Hilbert 空间对所有物理末态求和的几何代数恒等式。而在实际 $\beta$ 衰变中，衰变速率受限于有限衰变能窗 $Q_\beta = M(A, Z) - M(A, Z \pm 1)$，并受到相空间积分 $f_0 \sim Q_\beta^5$ 的加权。
   核形变导致单粒子轨道发生 Nilsson 劈裂，改变费米面处的轨道占据与泡利阻塞，使原本集中的 Gamow-Teller 巨共振（GTGR）强度发生展宽或分裂；粒子-振动耦合（PVC）在某些闭壳核（如 $^{56}\mathrm{Ni}$ 与 $^{132}\mathrm{Sn}$）中可打开原本在低能被阻塞的跃迁通道。因此，有限能窗内的实测衰变速率反映的是母核与子核能级拓扑与组态重叠，不可直接与 $3(N-Z)$ 等同。

2. **$\beta$ 缓发粒子发射的条件概率分解：**
   $\beta$ 缓发中子发射是一个严格的两步相继过程：
   - 第一步：母核通过 $\beta$ 跃迁馈送至子核激发能为 $E_x(i)$ 的分立能级或准连续谱态 $i$，其馈送分支比记为 $I_\beta(i)$（满足每母核衰变归一化 $\sum_i I_\beta(i) = 100\%$）。
   - 第二步：处于激发态 $i$ 的子核面临相互竞争的统计衰变通道：辐射 $\gamma$ 级联（部分宽度 $\Gamma_\gamma(i)$）与中子发射（部分宽度 $\Gamma_n(i)$，仅当 $E_x(i) > S_n$ 时开通）。
   总的 $x$ 中子发射几率表现为条件概率加权和：
   $$
   P_{xn} = \sum_i I_\beta(i) P(xn | i) = \sum_{i, E_x(i) > S_{xn}} I_\beta(i) \frac{\Gamma_{xn}(i)}{\Gamma_{\text{tot}}(i)}.
   $$
   由此可见：
   - 动学能窗 $Q_{\beta n} = Q_\beta - S_n$ 仅设定了中子发射的能量上限，绝非 $P_n$ 的充分预测公式；
   - 即使处于 $S_n$ 之上，若子核与孙核之间存在大角动量转移（需穿透高离心位垒 $l \ge 2$）或同位旋禁戒，$\Gamma_\gamma$ 仍可主导退激；
   - 必须严格区分单个中子发射几率 $P_{1n}$、至少发射一个中子的总几率 $P_{\ge 1n} = \sum_{x \ge 1} P_{xn}$ 以及平均中子多重度 $\langle M_n \rangle = \sum_{x \ge 1} x P_{xn}$，不同文献对“$P_n$”的记号必须依据其测量物理量映射。

3. **$0\nu\beta\beta$ 核矩阵元的动量标度与波函数调制：**
   在标准轻 Majorana 中微子交换机制下，半衰期标准参数化为：
   $$
   [T_{1/2}^{0\nu}]^{-1} = G_{0\nu} g_A^4 |M_{0\nu}|^2 \left| \frac{\langle m_{\beta\beta} \rangle}{m_e} \right|^2.
   $$
   - 动量标度差异：普通单 $\beta$ 衰变动量转移极低（$|\mathbf{p}| \approx 0$），而 $0\nu\beta\beta$ 中两个核子交换虚中微子，特征虚动量转移高达 $|\mathbf{p}| \sim 100\text{--}200\text{ MeV}/c$（探测短程距离 $r \sim 1\text{--}2\text{ fm}$）。
   - 手征两体接触项：Cirigliano 等（2018）指出，在手征有效场论框架下，为保证非微扰两核子散射的一致重整化，必须在领头阶引入 $\Delta L = 2$ 短程接触算符。该算符反映了短程中微子势的重整化自洽性，不可与单 $\beta$ 衰变的普通两体轴流（2BC）相混淆。
   - 形变与配对的波函数调制：超流配对关联增强初末态 BCS 基态之间的对跃迁，有利于增大 $M_{0\nu}$；而母核与子核之间的四极形变错位（例如从长椭球跃迁至扁椭球或球形核）显著削弱初末态内禀波函数的空间重叠，对 $M_{0\nu}$ 产生强烈抑制。不能仅凭单一寿命下限反演微观形变参数或轴矢量淬灭因子。

## Assumptions

- 弱衰变过程遵循轻子数守恒的标准电弱 $V-A$ 理论，但在 $0\nu\beta\beta$ 模块中假定中微子为轻 Majorana 粒子并满足轻中微子交换机制；
- 缓发粒子发射满足玻尔复合核统计假设，$\beta$ 馈送与后续粒子发射可处理为两阶段解耦过程；
- 中微子势在两核子间积分时假定采用闭合近似（Closure Approximation），即中间核态激发能相较于虚中微子特征动量（$\sim 100\text{ MeV}$）可作平均化处理。

## Competing Explanations

- **$P_n$ 能窗假说：** 早期经验模型常假设 $P_n$ 单纯随 $Q_\beta - S_n$ 增大而单调增长；现代数据库与微观模型表明，核壳层闭合与离心位垒可导致 $P_n$ 在跨壳时发生反常骤降，且 $S_n$ 以上的强 $\gamma$ 竞争不可忽略。
- **$0\nu\beta\beta$ 淬灭外推争论：** 某些计算将单 $\beta$ 衰变经验 $q_A \approx 0.75$ 的四次方带入双贝塔计算；现代理论表明高动量转移下短程接触项与高多极算符起关键作用，不能机械外推低能 $q_A$。

## Transfer Conditions

本笔记结论直接支撑博士论文第 4.7 节三子模块的写作；天体物理核合成网络中具体的核反应截面与元素丰度计算移交第 4.8 节；实验测量中的符合探测器立体角、死时间修正与定时算法移交第 5 章。

## Failure Conditions

- 将动学能窗 $Q_\beta - S_n > 0$ 当作必定发射缓发中子的充分条件；
- 混淆 $P_{1n}$、$P_{\ge 1n}$ 与平均中子多重度 $\langle M_n \rangle$ 的定义与数据映射；
- 将手征有效场论中的 $\Delta L = 2$ 短程接触算符误写为数值上必然主导矩阵元的普适结论；
- 从单一的 $0\nu\beta\beta$ 寿命测量下限反推出唯一的形变参量或 $g_A$ 淬灭数值。

## Falsification or Reverse Tests

- 在丰中子核 $\beta$ 衰变测量中，通过高纯锗与中子探测器符合测定 $E_x > S_n$ 能区发出的高能退激 $\gamma$ 射线总分支比，若该分支比显著大于零，则直接证伪“超过 $S_n$ 必发中子”的简化假设；
- 结合电荷交换反应 $(p, n)$ 与 $(n, p)$ 分别提取母核与子核的 Gamow-Teller 强度分布，检验理论模型预言的 $0\nu\beta\beta$ 虚跃迁中间态强度。

## Open Questions

- 远离稳定线极丰中子核（如超新星 $r$-过程快中子俘获关键等待点核）中一阶禁戒跃迁对总半衰期与多中子发射几率的具体贡献份额；
- 在手征有效场论框架下，用于无中微子双贝塔衰变短程接触项 $g_\nu^{NN}$ 的有限低能常数从格点 QCD 获得完全非微扰确定的进展。

## Human Review

本笔记由智能体基于 IAEA 缓发中子数据库、手征有效场论原件及从头算核矩阵元综述定向核读后建立，保留所有模型假设与适用边界；未进行真实用户审核。

## Promotion or Rejection History

- 2026-11-13：根据第 4.7 节写作任务建立，作为弱衰变能窗、缓发粒子发射与双贝塔核矩阵元讨论的理论物理依据。
