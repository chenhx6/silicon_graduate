---
type: research-note
title: "A130重写：跨核区非轴对称取向运动的微观机制、证据基线与迁移条件"
aliases: [A130 orientation cross region conditions 20261113, 跨核区取向对照研学笔记, G87 Section 4.4 证据研学]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
authors: [G87 (Gemini Tiered/high)]
created_from: "A130博士论文重写五章39节工程：第4.4节独占证据与科学推演（根据Sol父审定点修订版）"
promotion_target: doctoral-nuclear-structure-foundations
evidence_sources: [
  campaign-g07-gorgen-2004-163lu-quadrupole-moments,
  matta-2015-transverse-wobbling-135pr,
  lv-2022-evidence-against-wobbling-135pr,
  guo-2021-comment-transverse-wobbling-135pr,
  shimizu-2005-high-k-precession,
  sensharma-2020-longitudinal-wobbling-187au,
  guo-2022-low-spin-wobbling-187au,
  frauendorf-2014-transverse-wobbling,
  matsuzaki-2004-nuclear-inertia-and-wobbling,
  book-bohr-mottelson-nuclear-structure-vol2
]
tags: [doctoral-thesis, orientation-motion, transverse-wobbling, high-k-precession, 163lu, 135pr, 187au, evidence-audit]
---

# 同样叫三轴，为何有截然不同的取向运动

## Research Trigger

在原子核集体运动模型中，非轴对称形变参数 $\gamma$ 或相近的跃迁四极矩 $Q_t$ 常被用作表征三轴性的标量指标。然而在跨核区谱学比较中，同样具有三轴特征的原子核却表现出横向摆动（TW）、纵向摆动（LW）、手征双重带、高 $K$ 进动以及平面转动/$\gamma$ 振动混合等截然不同的动力学表现。本笔记旨在建立跨越 $Approx 130$、稀土区（$Approx 160$）以及超铪/重核区（$Approx 180$--$190$）的系统比较基线，剖析惯量主轴排序、准粒子对准几何与自旋相空间对取向模式的微观控制机制，确立取向模式跨区迁移的物理判据与失效边界。

## Grounded Evidence

| 物理体系 / 案例 | 原始文献与定位符 (Locator) | 证据性质与物理条件 | 边界与反例批判 |
|---|---|---|---|
| $^{163}\mathrm{Lu}$ TSD1/TSD2 经典摆动基准 | Görgen 2004 (PRC 69, 031301(R)), PDF pp. 2–3, Table I, Table II | 完全实测原表：Table I 测定 TSD1 (8态) 与 TSD2 (7态) $Q_t pprox 6.7$--$9.9\ \mathrm{b}$ 分布；Table II 测定 TSD2 $	o$ TSD1 连接线 $B(E2)_{\mathrm{out}} pprox 0.54$--$0.70\ e^2\mathrm{b}^2$ (按标准单粒子估计 $B_{\mathrm{W}}(E2) pprox 0.0053\ e^2\mathrm{b}^2$ 换算约 $100$--$130\ \mathrm{W.u.}$，非旧的 $0.024\ e^2\mathrm{b}^2$), $\delta pprox -3.10$ | 建立在强超形变 ($arepsilon_2 pprox 0.38$)、高自旋 ($R \sim 15$--$30\hbar \gg 1$) 与孤立 $\pi i_{13/2}$ 纯态之上；作为经典积累较为完整的参照，不教条推论“所有 TSD 必摆动” |
| $^{135}\mathrm{Pr}$ 低自旋横向摆动宣称 | Matta 2015 (PRL 114, 082501), PDF pp. 1–3, 5 | 实验报道：基于 $\pi h_{11/2}$ 负宇称激发带 (Band 3)，角分布拟合选定大根 $|\delta| > 1$ (如 747.3 keV 提取 $\delta = -2.0(4)$)，测得正线偏振度，宣称低自旋 TW | 忽略了角分布拟合固有的二次有理式代数双根多义性，且正线偏振未能排他性排除小根 |
| $^{135}\mathrm{Pr}$ 极化双根仲裁与摆动否定 | Lv 2022 (PLB 824, 136840), PDF pp. 2–5, Table 1; Guo 2021 (arXiv:2111.14150) | 实验批判与新测：747.3 keV (能级身份为 $17/2^- 	o 15/2^-$) 实验角关联比值 $R_{\mathrm{ac}}=0.98(7)$ 对应小根 $\delta = -0.47_{-0.22}^{+0.09}$；813.2 keV ($21/2^- 	o 19/2^-$) 小根 $\delta = -0.46_{-0.19}^{+0.11}$；同母态 $17/2^-$ 分支比 $B(E2; 747.3)/B(E2; 526.2) = 0.7_{-0.5}^{+0.7}$ 否定纯摆动声子；带间退激由 $M1$ 主导 (>80%)，带间 $B(E2)_{\mathrm{out}}$ 缺乏集体增强 | 带头核芯转动动量 $R \sim 1\hbar$ 违反简谐摆动近似前提；必须保留相容双根，不可主观单向选根；QTR 模型表明其本质为单粒子对准向转动轴倾斜的平面转动或与 $\gamma$ 振动带混合 |
| 高 $K$ 进动：三轴摆动的轴对称极限 | Shimizu, Matsuzaki, Matsuyanagi 2005 (PRC 72, 014306), PDF pp. 2–3 | 微观理论推导：在 $\gamma 	o 0$ 轴对称极限下，$\mathcal{J}_z 	o 0$ 使水平转动带收缩为单态，垂直摆动声子序列退化为绕对称轴进动的高 $K$ 转动带 $E(I) = rac{\hbar^2}{2\mathcal{J}_\perp}[I(I+1)-K^2]$，进动频率 $\omega_{\mathrm{prec}} = rac{\hbar I}{\mathcal{J}_\perp}$ | 统一了三轴摆动与高 $K$ 进动的角动量取向几何，但明确区分随体旋转系与实验室固定 $K$ 参考系，并非所有轴对称构型均能绕对称轴集体自转 |
| $^{187}\mathrm{Au}$ 纵向摆动宣称与实验检验 | Sensharma 2020 (PRL 124, 052501), PDF pp. 1–3; Guo 2022 (PLB 828, 137010), PDF pp. 2–4 | 实验争论：Sensharma 宣称 $\pi h_{9/2}$ 纵向摆动；Guo 2022 实测 376 keV ($11/2^- 	o 9/2^-$) 与 462 keV ($15/2^- 	o 13/2^-$) 支持小根 $\delta pprox -0.26, -0.28$，通过采用 $^{186}\mathrm{Pt}$ 核芯或带内 $B(E2)_{\mathrm{in}} \sim 100$--$200\ \mathrm{W.u.}$ 估算带间跃迁仅几个 W.u. ($B(E2)_{\mathrm{out}}/B(E2)_{\mathrm{in}} < 0.1$) | 奇质子处于 $h_{9/2}$ 底壳倾向短轴 $s$ 对准与 LW 要求的中轴 $m$ 对准产生模型分歧；带头 $R \sim 1\hbar$ 缺乏恢复力；支持长椭--扁椭三轴形状共存与单粒子态激发解释 |
| 重区 Os/Pt/Hg 形状共存与 $\gamma$ 软度 | Prochniak & Rohozinski 2009 (JPG 36, 123101), PDF pp. 36–39 | 唯象与微观计算：微观势能面在 $\gamma$ 方向极度平坦，零点涨落大，存在长椭--扁椭形状共存 | 不可简单给整个 $Approx 190$ 区域贴统一固定扁椭或强八极标签，须逐核逐态分析 |

## Provisional Reasoning

### 1. 惯量主轴排序与准粒子对准几何

- 区分电荷几何主轴 ($s/m/l$ 表示短/中/长轴，半径 $R_s < R_m < R_l$ 于 Lund 约定 $\gamma \in (0^\circ, 60^\circ)$) 与转动惯量主轴张量。
- 经典流体无辐散流在 $\gamma < 30^\circ$ 扇区给出中轴最大惯量 ($\mathcal{J}_m > \mathcal{J}_s > \mathcal{J}_l$，在 $\gamma = 30^\circ$ 处 $\mathcal{J}_s = \mathcal{J}_l$，而在 $\gamma > 30^\circ$ 处 $\mathcal{J}_m > \mathcal{J}_l > \mathcal{J}_s$)；刚体转子给出短轴最大惯量 ($\mathcal{J}_s > \mathcal{J}_m > \mathcal{J}_l$)；微观配对相互作用大幅压低惯量并导致横向惯量呈现频率依赖性 $\mathcal{J}_k(\omega)$。
- 准粒子费米面位置决定内禀对准驱动力：底壳粒子型倾向短轴 $s$（如 $^{163}\mathrm{Lu}$ 的 $\pi i_{13/2}$）；顶壳空穴型倾向长轴 $l$；半满壳倾向中轴 $m$。
- 横向摆动 (TW) 与纵向摆动 (LW) 的严格定义是准粒子角动量 $\mathbf{j}$ 相对模型所指定的最大转动惯量轴的对准几何，而非绝对中轴标签。删除伪闭式公式，强调其依赖于准粒子冻结对准与特定核芯惯量排序假设。

### 2. $^{163}\mathrm{Lu}$ 的实测原表数据分析

- Görgen et al. (2004) Table I 中 TSD1 与 TSD2 的 $Q_t$ 分布在 $6.7$--$9.9\ \mathrm{b}$ 区间，体现了两带基于相近超形变核芯的特征。
- Table II 中 5 行带间跃迁实测 $B(E2)_{\mathrm{out}} pprox 0.54$--$0.70\ e^2\mathrm{b}^2$。采用标准单粒子 Weisskopf 公式 $B_{\mathrm{W}}(E2) pprox 0.05940 A^{4/3}\ e^2\mathrm{fm}^4 pprox 0.0053\ e^2\mathrm{b}^2$ ($A=163, R_0=1.2\ \mathrm{fm}$)，换算对应约 $100$--$130\ \mathrm{W.u.}$，绝不可复用旧的 $0.024\ e^2\mathrm{b}^2$。结合 $\delta pprox -3.10$ ($E2$ 占约 90%)，支持核芯集体横向进动的理论图像。
- 明确 $^{163}\mathrm{Lu}$ 发生在 $R \sim 15$--$30\hbar$ 强转动极限与高 $j$ 孤立轨道的特殊边界，破除教条泛化。

### 3. $^{135}\mathrm{Pr}$ 的角分布双根与低自旋模式演化

- 角分布各向异性函数 $W(	heta)$ 是关于混合比 $\delta$ 的二次有理式，拟合代数上通常存在大根 $|\delta_1| > 1$ 与小根 $|\delta_2| < 1$。线偏振正负号不能排他性排除小根。
- Lv et al. (2022) 证明 747.3 keV ($17/2^- 	o 15/2^-$) 跃迁小根解 $\delta = -0.47_{-0.22}^{+0.09}$，带间退激由 $M1$ 主导 (>80%)；同母态 $17/2^-$ 分支比 $B(E2; 747.3)/B(E2; 526.2) = 0.7_{-0.5}^{+0.7}$ 证明波函数混合，带间 $B(E2)_{\mathrm{out}}$ 缺乏集体增强。
- 结合带头核芯转动 $R \sim 1\hbar$ 破坏谐振子强转动近似，该带更自然解释为准粒子对准向旋转轴倾斜的平面转动或与 $\gamma$ 振动带混合。

### 4. 高 $K$ 进动极限与重区形状共存

- Shimizu et al. (2005) 证明高 $K$ 进动是三轴摆动在 $\gamma 	o 0$ 轴对称极限下的连续退化：$\mathcal{J}_z 	o 0$ 使得水平转动带收缩为单态，垂直摆动声子序列退化为绕对称轴进动的高 $K$ 转动带 $E(I) = rac{\hbar^2}{2\mathcal{J}_\perp}[I(I+1)-K^2]$，进动频率 $\omega_{\mathrm{prec}} = rac{\hbar I}{\mathcal{J}_\perp}$。
- $^{187}\mathrm{Au}$ 纵向摆动面临质子处于 $h_{9/2}$ 底壳倾向短轴对准（与 LW 中轴对准模型假设分歧）以及带头 $R \sim 1\hbar$ 的理论问题；Guo et al. (2022) 实测小根 $\delta pprox -0.26, -0.28$，采用 $^{186}\mathrm{Pt}$ 估算带间 $E2$ 仅几个 W.u.，明确其采用依赖性，支持长椭--扁椭形状共存解释。
- 重核区 Os/Pt/Hg 普遍表现为微观势能面在 $\gamma$ 方向极度平坦的软三轴与多重形状共存，不可贴单一固定标签。

## Assumptions

- 体系具有明确的四极内禀参考系展开；微观配对与准粒子激发在定域推转框架下处理。
- 摆动运动在强转动极限（$R \gg 1$）下近似满足谐振子恢复势展开。
- 角分布分析严格遵循 RACAH 代数与方向角关联统计张量规范。

## Competing Explanations

1. **$^{135}\mathrm{Pr}$ 低自旋横向摆动 vs 平面转动/单粒子重对准**：大根拟合支持 TW，但小根解 $\delta = -0.47_{-0.22}^{+0.09}$ 与实验完全相容且给出 $M1$ 主导退激，同母态分支比约为 0.7 证明能带混合，配合低核芯自旋 $R \sim 1\hbar$，单粒子重对准平面转动更为自洽。
2. **$^{187}\mathrm{Au}$ 纵向摆动 vs 三轴形状共存**：LW 假设与壳底准粒子短轴对准倾向存在模型分歧，带头 $R \sim 1\hbar$ 缺乏恢复力；其带间微弱 $E2$ 强度依赖于采用 $^{186}\mathrm{Pt}$ 核芯估算，被长椭--扁椭三轴多构型共存态自然解释。
3. **高 $K$ 转动与三轴摆动的隔离 vs 轴对称极限统一**：传统观点将二者割裂，Shimizu 2005 证明高 $K$ 进动是摆动运动在 $\gamma 	o 0$ 下的连续退化极限。

## Transfer Conditions

本笔记确立的惯量主轴排序、准粒子对准几何、角分布双根仲裁定理以及轴对称退化极限，直接支撑博士论文第4.4节的正式正文（`Tex/Sections/sec-4-4.tex`）与独立证据账本（`latex-evidence-ledger/section-4-4.json`）。该分析框架可平滑迁移至第4.2节（$Approx 130$ 手征与摆动带）、第4.3节（稀土超形变态）以及第5.7节（角关联、偏振和 $\delta$ 反演）。

## Failure Conditions

- 将质量区名称作为排他互斥的物理机制标签。
- 依据模型偏好人为删除实验相容的 $\delta$ 双根中的某一个解。
- 混淆不同实验装置的测量结果，或引用理论文章发表年份代替实际测量年份。
- 虚构未测量的绝对 $B(E2)$ 跃迁值或给未测核贴确定性标签。
- 忽略低自旋下核芯转动 $R \sim 1\hbar$ 对简谐摆动近似的根本破坏。

## Falsification or Reverse Tests

- **反向检验 1**：在三轴转子模型中令形变角 $\gamma 	o 0^\circ$，检查摆动激发能量公式是否严格退化为 Shimizu 2005 的轴对称高 $K$ 进动能量公式 $E(I) = rac{\hbar^2}{2\mathcal{J}_\perp}[I(I+1)-K^2]$。
- **反向检验 2**：对任意给定的角分布系数 $(A_2, A_4)$，代入二次有理式反解 $\delta$，检查判别式是否通常给出两个实根解（一大一小）。
- **反向检验 3**：在粒子--转子模型中放开奇核子角动量冻结限制，检查低自旋态下角动量是否发生向主旋转平面的倾斜滑移。

## Open Questions

1. 在 $Approx 130$ 区中重核中，是否存在能够在较高自旋（$R \gtrsim 10\hbar$）下同时维持稳定深三轴势阱并展现真正集体摆动声子的候选体系？
2. 在强激光或重离子极化靶实验中，如何利用高自旋对准态的自旋极化进动直接在时域分离摆动声子与单粒子进动周期？
3. 在过渡区奇奇核中，手征双重带（三维非共面旋转）与横向摆动（二维平面微扰进动）在微观多体波函数层面的临界分叉边界如何由微观能量泛函统一预测？

## Human Review

- 2026-11-13：由 G87 (Gemini Tiered/high) 完成全节科学推导与原件证据核查，确立四大核心案例与五大子模块，按父代理 Sol 审查意见定点修订：删除伪闭式公式、厘清无辐散流惯量扇区条件、核准 135Pr 747.3 keV ($17/2^- 	o 15/2^-$) 真实自旋及小根 $\delta = -0.47(+0.09/-0.22)$ 与分支比 0.7、校正 163Lu Weisskopf 换算 $B_{\mathrm{W}}(E2) pprox 0.0053\ e^2\mathrm{b}^2$ 对应 100–130 W.u.、明确 187Au 小根 $\delta pprox -0.26, -0.28$ 及采用 186Pt 估算依赖性、规范 Shimizu 2005 进动公式 $\hbar$ 单位。

## Promotion or Rejection History

| Date | Event | Previous State | New State | Reason / Triggering Evidence | Target or Successor |
|---|---|---|---|---|---|
| 2026-11-13 | 建立第4.4节独占研学笔记 | none | provisional | 承接F02/F03合同与39节架构，全面固化跨核区取向对照微观证据链 | doctoral-nuclear-structure-foundations |
| 2026-11-13 | 定点修订全节科学断言与数据 | provisional | provisional | 响应父审意见：删除伪闭式公式、修正135Pr能级跃迁与小根数值、校正163Lu Weisskopf换算与Qt范围、明确187Au采用量依赖性与Shimizu公式单位 | doctoral-nuclear-structure-foundations |
