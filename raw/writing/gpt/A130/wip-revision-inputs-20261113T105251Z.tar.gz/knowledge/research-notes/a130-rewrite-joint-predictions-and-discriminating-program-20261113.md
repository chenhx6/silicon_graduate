---
type: research-note
title: "A130重写：低能核结构模式判据、联合前向预言与可证伪研究候选"
aliases: [joint-predictions-and-discriminating-program, section-3-8-research-card]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
created_from: "父级派发第3.8节任务指令及98Mo、102Ru、135Pr原件核查与R3反演边界"
promotion_target: ""
evidence_sources: [lawrie-2020-tilted-precession-wobbling, frauendorf-2014-transverse-wobbling, nomura-2022-questioning-wobbling-ibfm, lv-2022-evidence-against-wobbling-135pr, karmakar-2025-98mo-dae, saracino-2026-102ru-scissors-octupole-resonances]
tags: [doctoral-thesis, section-3-8, joint-predictions, holdout-validation, falsification, research-program]
---

# 模式判断需要怎样的联合预言：从命名候选到可证伪研究问题

## Research Trigger

在低能核结构高自旋谱学研究中，学者常基于个别能级比值（如接近转子或谐振子比值）或一条增强的带间跃迁，直接给实验观测能带赋予“手征带”、“摆动带”、“剪刀模”或“八极带”等特征模式标签。然而，这一研究范式极易陷入“过拟合简并”：不同甚至相互冲突的微观或唯象模型，通过对若干自由参数的微调，均能在可接受精度内拟合现有的低自旋能级。

本笔记旨在确立第3.8节《模式判断需要怎样的联合预言》的方法论基准：将“模式命名”转变为包含明确前向预言、最强竞争解释与独立高阶观测量的可证伪研究问题；建立数据分层与留出检验规范；并在已有实验基线上提出三个具体可证伪的研究候选方案。

## Grounded Evidence

| 证据来源 | 物理载荷与定位 | 适用边界与限制 |
|---|---|---|
| Lawrie, Shirinda & Petrache (PRC 2020) | 三轴核倾斜进动(TiP)与摆动近似条件；PDF p. 2 Fig. 1能谱演化，p. 4 Fig. 4近似条件函数f(n,I) | 经典进动角动量轨迹仅在特定惯量与自旋窗口满足简谐摆动展开 |
| Frauendorf & Dönau (PRC 2014) | PRM横向摆动模型；PDF p. 4各向异性惯量假定与短轴顺排 | 冻结准粒子角动量属于教学简化近似，并非所有PRM计算的必然前提 |
| Nomura & Petrache (PRC 2022) | CDFT/Gogny自洽映射至IBFM；PDF p. 1 Table I与带间E2强度压低 | 证明gamma软核表面激发与单粒子激发混合能产生类摆动能级假象 |
| Lv et al. (PLB 2022) | 135Pr带间跃迁角分布双根拟合与偏振分析；PDF p. 3 Table 1, Fig. 2 | 偏振数据兼容小根解(delta=-0.47(+9/-22))，实测B(E2;747)/B(E2;526)=0.7(+7/-5)表明两跃迁相近 |
| Karmakar et al. (NPA 2025 / DAE 2025) | 98Mo弱E3跃迁候选与能级纲图；PDF p. 4 Table 1 | 虽观测到跨带弱E3，但母态绝对寿命未定，比值受分母E2受阻与分子增强双重影响 |
| Saracino et al. (PRL 2026) | 102Ru低能偶极响应与八极共振共存；PDF p. 2 Fig. 1, p. 4 E1压低分析 | NRF测定0+到1-为E1激发（受IVGDR耦合压低），不能直接由0+经E3激发同一1-态 |

## Provisional Reasoning

1. **理论模型的前向预言结构**：
   一个自洽的物理模型由微观坐标集（如欧拉角、玻尔形变beta/gamma、准粒子产生湮灭算符）、守恒量子数与离散对称性标签、微观输入（PES势能曲面、微观惯量张量、配对隙Delta及有效算符）构成。必须明确划分哪些参数被用于拟合（如基带转动惯量或能隙），模型的前向预言严格限定在未参与拟合的留出观测空间。

2. **竞争解释的重叠与不可通约性**：
   不同的微观机制（如纯转子摆动、倾斜进动、gamma软核耦合、准粒子顺排带交叉）在低自旋区往往共享极为相似的能级间隔。因此，绝不能设立人为的“通用判据阈值”（如将delta>1或E2支额>50%作为模式存在的充要条件）。在角分布分析中，勒让德多项式二次展开产生的双根解必须完整保留，不能因理论偏好剔除小根或大根。

3. **数据分层与误差协方差**：
   实验数据严格划分为四层：原始测量量（raw counts, coincidence matrices）、采用量（adopted energy, half-life）、派生量（derived B(E2), B(M1), delta）、模型输出（model eigenvalues, wavefunction weights）。由同一母态寿命和不同支额推导出的多个B(EL)存在强协方差相关，共用数据不能作为独立重复证据。若引入高斯残差与权重逆矩阵，必须在声明协方差与分布假设下进行，避免无raw counts的虚假显著性检验。

## Assumptions

- 假定实验分析中所采用的谱仪探测效率与角分布响应经过充分校准。
- 假定电磁跃迁算符的有效电荷与多极矩阵元满足对应能区的微观模型空间截断规范。
- 假定在束高自旋激发态的衰变级联不包含未被识别的超长寿命阻塞同核异能态。

## Competing Explanations

- **三轴摆动 vs 倾斜进动 vs 软核玻色子耦合**：在奇A核中，能谱的交错既可解释为绕短轴进动的横向摆动声子，亦可解释为准粒子角动量向中间轴顺排的倾斜进动，或gamma软核与单费米子的代数耦合。
- **八极集体增强 vs 极度受阻的低能E2分母**：在弱跃迁分支比中，显著的E3/E2比值既可能源于分子E3的集体增强，也可能源于分母E2跃迁因结构阻碍（如形状变化或K禁戒）而被严重压低。

## Transfer Conditions

- 跨质量区的模式推广必须基于单粒子轨道占据、费米面位置、微观对能隙、自洽转动惯量与布居反应机制，绝不能由局部文献缺乏或特定核区未见报道便宣称“首次发现”。

## Failure Conditions

- 若所提出的模型预言在未参与拟合的高自旋回弯点、绝对跃迁寿命或线偏振度实测前发生方向性偏离，则前向预言失败。
- 若将共用同一套探测数据或相同寿命输入的衍生跃迁矩阵元作为多个互证证据，则统计推断链条失效。

## Falsification or Reverse Tests

- **寿命判决测试**：通过反冲距离多普勒位移法（RDM）或多普勒频移衰减法（DSAM）测定母态绝对寿命，将相对跃迁比转化为绝对B(EL)强度，检验其是否达到微观集体增强量级。
- **线偏振度双根仲裁测试**：利用分段高纯锗康普顿散射线偏振度，对角分布中大根与小根解进行严格正负不对称度仲裁，判定跃迁是E2主导还是M1主导。

## Open Questions

- 如何在超精细能级间距与微弱分支比极限下，定量区分单粒子微观态混合与大振幅连续集体软振动的谱学指纹？
- 在缺乏稳定靶支持的放射性核束实验中，如何利用极弱束流下的重离子库仑激发多极矩阵元求和规则提取形状不变量？

## Human Review

- 2026-11-13：由G85根据父级指示确立第3.8节方法论标准与三个具体可证伪候选研究方案。

## Promotion or Rejection History

- 2026-11-13：作为博士论文第3章压轴方法论节的研究纲领，提供可复用L3研究架构。
