---
type: research-note
title: "A130重写：环境热浴、电子通道与反应形成怎样重塑物理可见性"
aliases: [A130 environment formation observability 20261113, 环境与形成路径改变可见性研学笔记, G89 Section 4.8 证据研学]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
authors: [G87 (Gemini Tiered/high), G89 (Gemini Tiered/high)]
created_from: "A130博士论文重写五章39节工程：第4.8节独占证据与科学推演（根据G89定点返修）"
promotion_target: doctoral-nuclear-structure-foundations
evidence_sources: [gintautas-2009-176lu-thermal-equilibration, gosselin-2010-plasma-isomers-176lu-180ta, seiferle-2017-lifetime-229th-isomer, beeks-2021-thorium-229-isomer-nuclear-clock, kraemer-2023-radiative-decay-229th-isomer, chiara-2018-mo93m-isomer-depletion-neec, wu-2019-mo93m-neec-stopping-theory, guo-2021-mo93m-depletion-contamination-challenge, guo-2022-mo93m-isomer-beam-depletion-limit, zagrebaev-2001-superheavy-synthesis-survival, xu-2004-superheavy-high-spin-isomer-stability, book-jain-nuclear-isomers]
tags: [environment-effects, open-rate-network, detailed-balance, thermalization-timescale, internal-conversion, neec, neies, neet, th229-clock, mo93m-depletion, heavy-ion-fusion, evaporation-residue, fission-barrier-damping, xu2004-decoupling, observational-selection]
---

## Research Trigger

在A130博士论文前述讨论中，原子核内禀结构与电磁跃迁常在冷态或孤立真空假定下推导。针对第4.6节与第4.7节导出的异能态微观性质，极易产生将冷态长寿命等同于高温恒星等离子体中长久存活、或等同于重离子熔合反应中大产生截面的误区。本笔记针对第4.8节的物理要求，推导环境热浴、原子电子通道与重离子动力学形成三阶段对核态可见性的重塑机制，消除旧稿中的事实与量纲错误，并为正式正文提供完备的物理图像与证据链。

## Grounded Evidence

本笔记基于以下实验原件与理论文献的直接核读：
1. **热网络与 s-过程同核异能态**：
   - [[gintautas-2009-176lu-thermal-equilibration]]：PRC 80, 015806 (2009)。回读 PDF pp. 1–3，核对 $^{176}\mathrm{Lu}$ 基态 $J^\pi = 7^-$ ($K=7$, $T_{1/2} = 3.76 \times 10^{10}\ \mathrm{yr}$) 与异能态 $^{176m}\mathrm{Lu}$ ($J^\pi = 1^+$, $K=1$, $E_x = 122.9\ \mathrm{keV}$, $T_{1/2} = 3.66\ \mathrm{h}$)。明确直接 $\Delta K = 6$ 跃迁被高度阻碍，跨带热化由高激发中间桥态介导。
   - [[gosselin-2010-plasma-isomers-176lu-180ta]]：PRC 81, 055808 (2010)。PDF pp. 1–4，分析等离子体电子过程与热光子场对 $^{176}\mathrm{Lu}$ 与 $^{180}\mathrm{Ta}$ 跃迁率的调制，指出热平衡判据取决于微观激发率与两态弱衰变率的竞争。
2. **核钟跃迁与原子电子通道**：
   - [[seiferle-2017-lifetime-229th-isomer]]：PRL 118, 042501 (2017)。独立测量中性 $^{229m}\mathrm{Th}$ 原子表面内转换半衰期 $T_{1/2} = 7 \pm 1\ \mu\mathrm{s}$（平均寿命 $\tau \approx 10\ \mu\mathrm{s}$），确立中性钍中内转换系数 $\alpha_{\mathrm{IC}} \approx 10^9$。
   - [[kraemer-2023-radiative-decay-229th-isomer]]：Nature 617, 706 (2023)。回读原 PDF pp. 1, 3，测得植入 $\mathrm{MgF}_2$ 晶体中 $^{229m}\mathrm{Th}$ 的辐射半衰期为 $T_{1/2}(\mathrm{MgF}_2) = 670(102)\ \mathrm{s}$（跃迁波长 $148.71 \pm 0.42\ \mathrm{nm}$，能量 $8.338 \pm 0.024\ \mathrm{eV}$）。折射率宏观因子 $n^3$ 为介质虚腔模型推算真空速率所用，非直接真空测量。宽禁带有效抑制价带普通内转换，但晶格缺陷非辐射淬灭不可先验假定为零。
3. **Mo-93m 诱发退激争议**：
   - [[chiara-2018-mo93m-isomer-depletion-neec]]：Nature 554, 216 (2018)。实验在阿贡 ATLAS，利用 $^{7}\mathrm{Li}(^{90}\mathrm{Zr}, p3n)^{93m}\mathrm{Mo}$ 逆运动学反应产生反冲离子，在碳膜慢化中报道多重符合，宣称测得激发几率 $P_{\mathrm{exc}} = 1.0(3)\%$。
   - [[wu-2019-mo93m-neec-stopping-theory]]：PRL 122, 212501 (2019)。相对论 MCDF 与 CasP 阻止本领理论计算给出总 NEEC 几率 $P_{\mathrm{theory}} \approx (2.26\text{--}2.73) \times 10^{-11}$，与 Chiara 实验相差 9 个数量级。
   - [[guo-2021-mo93m-depletion-contamination-challenge]]：Nature 594, E1 (2021)。指出强瞬发熔合蒸发 $\gamma$ 本底及靶杂质反应模拟虚假 $268\ \mathrm{keV}$ 符合峰的可能性。
   - [[guo-2022-mo93m-isomer-beam-depletion-limit]]：PRL 128, 242502 (2022)。回读原 PDF pp. 2–4。实验在兰州 HIRFL / RIBLL 35 米次级束流线，初级反应 $^{12}\mathrm{C}(^{86}\mathrm{Kr}, 5n)$，初束 $559\ \mathrm{MeV}$，选出 $460\ \mathrm{MeV}$ $^{93m}\mathrm{Mo}^{36+}$ 离子（异能纯度 $\sim 0.6\%$）。在 $266.5\text{--}269.5\ \mathrm{keV}$ 窗内观测 570 计数（本底 596 计数，$3\sigma$ 下限 523 计数），以高斯峰在 $3\ \mathrm{keV}$ 窗内的 $95\%$ 面积接受度提取峰计数上限 $\sim 50$，导出激发几率上限 $P_{\mathrm{max}} \approx 2 \times 10^{-5}$。
4. **重离子完全熔合与超重核异能态**：
   - [[zagrebaev-2001-superheavy-synthesis-survival]]：PRC 65, 014607 (2001)。分波熔合截面 $\sigma_{\mathrm{ER}}(E) = \sum_J \sigma_{\mathrm{cap}}(E, J) P_{\mathrm{CN}}(E, J) W_{\mathrm{sur}}(E^*, J)$，剖析准裂变竞争及壳修正随激发能的阻尼。
   - [[xu-2004-superheavy-high-spin-isomer-stability]]：PRL 92, 252501 (2004)。计算超重核高 $K$ 态冷自发裂变位垒增高，澄清该增高并不等同于高温复合核存活几率增大。
   - [[book-jain-nuclear-isomers]]：同核异能态物理机制专著，确立阻碍跃迁与谱学退激级联规律。

## Provisional Reasoning

## 1. 开放速率网络方程与流动损失

全系统能级演化服从一阶非齐次常微分方程组：
$$
\frac{d \mathbf{N}(t)}{dt} = \mathbf{A}(T, n_e, \dots) \mathbf{N}(t) + \mathbf{P}(t),
$$
其中 $\mathbf{N}(t) = (N_1(t), \dots, N_M(t))^T$ 为各离散能级的粒子数密度向量（单位 $\mathrm{cm}^{-3}$，非核子数）。非对角矩阵元 $A_{ij} = \lambda_{j \to i} \ge 0$ ($i \ne j$) 为单向跃迁速率常数；对角元为：
$$
A_{ii} = -\sum_{j \ne i} \lambda_{i \to j} - d_i^{\mathrm{sink}} \le 0.
$$
各列和满足 $\sum_{i=1}^M A_{ij} = -d_j^{\mathrm{sink}} \le 0$。总核素布居密度 $N_{\mathrm{tot}} = \sum_i N_i$ 随时间演化为：
$$
\frac{d N_{\mathrm{tot}}}{dt} = -\sum_{i=1}^M d_i^{\mathrm{sink}} N_i(t) + \sum_{i=1}^M P_i(t).
$$
当且仅当系统闭合（所有 $d_i^{\mathrm{sink}} = 0$）且无外源（$\mathbf{P} = 0$）时，总核素数密度守恒。

## 2. 成对可逆电磁跃迁的微观详细平衡及其严格边界

在温度为 $T$ 的 Planck 热辐射光子浴中，能量为 $\Delta = E_u - E_l$ 的光子平均占据数由 Bose-Einstein 分布给出：
$$
n_\gamma(\Delta) = \frac{1}{\exp\left(\frac{\Delta}{kT}\right) - 1}.
$$
注意 $n_\gamma$ 为相空间平均占据数，当 $\Delta < kT \ln 2$ 时 $n_\gamma > 1$，非概率。任意成对结合能级 $|l\rangle$（低）与 $|u\rangle$（高）之间的自发/受激发射率与光共振吸收率满足 Einstein 详细平衡关系：
$$
\lambda_{u \to l} = A_{ul} [1 + n_\gamma(\Delta)], \qquad \lambda_{l \to u} = \frac{2J_u + 1}{2J_l + 1} A_{ul} n_\gamma(\Delta),
$$
$$
\frac{\lambda_{l \to u}}{\lambda_{u \to l}} = \frac{2J_u + 1}{2J_l + 1} \exp\left(-\frac{\Delta}{kT}\right).
$$
**边界确立**：成对详细平衡仅在所声明的 Planck 辐射浴中对该对可逆电磁跃迁严格成立。它不能直接外推为整个开放核反应网络的全局 Boltzmann 平衡（$N_m/N_g = \frac{2J_m+1}{2J_g+1} e^{-(E_m-E_g)/kT}$），因为非对称弱衰变漏失 $d_i^{\mathrm{sink}}$、连续外源馈入 $\mathbf{P}(t)$ 以及有限跨带热化时间尺度均会打破全局热平衡。在声明的典型 $s$-过程氦燃烧壳层等透明天体环境（中微子平均自由程远大于恒星核尺寸）中，可合理忽略逆中微子流；但在核心坍缩等中微子不透明致密环境中该假定不成立。

## 3. 跨簇热化动力学与时间尺度

将核能级划分为基态簇 $g$ 与异能态簇 $m$。带内能级间虽有快速纳秒/皮秒级自发退激，但带内快速建立热平衡的前提是环境光子占据数足以驱动快速向上跃迁。
两簇间直接电磁跃迁由于高度禁戒（例如 $^{176}\mathrm{Lu}$ 中基态 $K=7$ 与异能态 $K=1$ 之间的 $\Delta K = 6$）被强烈压制，直接跃迁率可合理近似忽略（物理阻碍近似，非算符严格恒等于零）。跨带跃迁主要通过高激发能量的中间桥态 $|i\rangle$ 实现。对寿命远短于全簇演化尺度的桥态进行绝热消去，并计入后续多步退激级联的完整分支流，给出两簇有效交换方程：
$$
\frac{d}{dt}\begin{pmatrix} N_g \\ N_m \end{pmatrix} =
\begin{pmatrix} -(a + D_g) & b \\ a & -(b + D_m) \end{pmatrix}
\begin{pmatrix} N_g \\ N_m \end{pmatrix} +
\begin{pmatrix} P_g \\ P_m \end{pmatrix},
$$
其中 $a = \sum_i \lambda_{g \to i} B_{i \to m}$，$b = \sum_i \lambda_{m \to i} B_{i \to g}$。在恒定温度与无外源条件下，特征值为：
$$
r_\pm = \frac{1}{2}\left\{ (a + b + D_g + D_m) \pm \sqrt{(a + D_g - b - D_m)^2 + 4ab} \right\}.
$$
- **等漏失极限**：当 $D_g = D_m = D$ 时（包含严格闭合无损失 $D=0$ 作为特例），$\sqrt{(a-b)^2+4ab} = a+b$，特征值为 $r_- = D$，$r_+ = a+b+D$。归一化两簇布居差分按速率 $r_+ - r_- = a+b$ 弛豫，故特征热化时间为 $\tau_{\mathrm{therm}} = 1/(a+b)$。闭合无漏失是充分条件而非唯一必要条件。
- **快速热化弱漏失极限**：当 $a+b \gg |D_g - D_m|$ 时，较小特征值给出系统宏观有效衰变破坏率：
$$
r_- \simeq D_{\mathrm{eff}}(T) = \frac{b D_g + a D_m}{a + b} \simeq \frac{Z_g(T) D_g + Z_m(T) e^{-(E_m-E_g)/kT} D_m}{Z_g(T) + Z_m(T) e^{-(E_m-E_g)/kT}}.
$$
- **时变环境**：当恒星温度 $T(t)$ 与馈入 $\mathbf{P}(t)$ 随时间演化时，系统非自治，瞬时特征值不能自动构成通解，必须积分全微分方程组。

## 4. 核与电子通道竞争：核钟跃迁与诱发退激争议

在 SI 单位制与 Suhonen 电荷型磁算符体系下，核电磁跃迁率标准表达式为：
$$
\lambda_\gamma(\sigma L) = \frac{8\pi(L+1)}{L[(2L+1)!!]^2} \frac{1}{4\pi\varepsilon_0 \hbar} \left(\frac{E_\gamma}{\hbar c}\right)^{2L+1} B(\sigma L).
$$
对于 $M1$ 跃迁，$\Gamma_\gamma(M1) = \hbar \lambda_\gamma(M1) = \frac{16\pi}{9} \frac{1}{4\pi\varepsilon_0} \left(\frac{E_\gamma}{\hbar c}\right)^3 B_S(M1)$。引入无量纲约化跃迁几率 $b_{M1} = \frac{B_S(M1)}{(\mu_N/c)^2} = \frac{B_\mu(M1)}{\mu_N^2}$ 后，实用跃迁率为 $\lambda_\gamma(M1) = C_{M1} (E_\gamma/\mathrm{MeV})^3 b_{M1}$，常数 $C_{M1} \approx 1.7584 \times 10^{13}\ \mathrm{s}^{-1}$。不可对已归一的数值 $b_{M1}$ 重复乘除光速 $c^2$。

核能级实验总宽度与寿命受核外电子通道强烈调制：$\Gamma_{\mathrm{tot}} = \Gamma_\gamma (1 + \alpha_{\mathrm{IC}}) + \Gamma_{\mathrm{ext}}$。外驱过程（强激光、等离子体）需用主方程或密度矩阵处理，不能概括为常数 $\Gamma_{\mathrm{ext}}$。
- **内转换（IC）**：束缚电子吸收能量电离，$E_e = \Delta E_{\mathrm{nuc}} - E_b > 0$。通道开放严格依赖于电子轨道结合能与占据；高度电离裸离子会关闭对应内转换通道，使寿命大幅反向延长。不存在普遍适用的 $\alpha_{\mathrm{IC}} \propto E^{-(L+0.5)}$ 幂律，低能并不无条件由内转换主导。
- **电子俘获核激发（NEEC）**：连续态自由电子被离子束缚态空穴共振俘获，逆内转换过程。共振条件为 $E_e + E_b = \Delta E_{\mathrm{nuc}} \equiv E_t - E_i$（核激发能差，非异能态对基态的绝对能量）。具有有限 Breit-Wigner 截面共振线宽。
- **非弹性电子散射（NEIES）**：连续态自由电子与核碰撞发生非弹性散射（连续到连续），阈值过程 $E_e > \Delta E_{\mathrm{nuc}}$。
- **电子跃迁核激发（NEET）**：束缚态电子跃迁 $e^-_1 \to e^-_2$ 虚光子耦合诱发核激发，要求电子与核能级差高度简并 $\Delta E_{\mathrm{el}} \approx \Delta E_{\mathrm{nuc}}$。

**原件核对案例**：
- $^{229}\mathrm{Th}$：中性原子价层内转换半衰期由 Seiferle 2017 原件独立测得为 $T_{1/2} = 7 \pm 1\ \mu\mathrm{s}$（直接原件 PRL 118, 042501）。植入宽带隙氟化物晶体中，Kraemer 2023 原件（Nature 617, 706，PDF pp. 1, 3）直接给出 $\mathrm{MgF}_2$ 晶体中半衰期为 $670(102)\ \mathrm{s}$（非 $\mathrm{CaF}_2$ 平均寿命）。折射率宏观因子 $n^3$ 属介质局域场模型推算真空速率，非直接真空测量；晶格缺陷淬灭不可先验假设为零。
- $^{93m}\mathrm{Mo}$：Chiara 2018 宣称观测到 $P_{\mathrm{exc}} = 1.0(3)\%$ 的 NEEC 耗散，其实际反应为 ATLAS 的 $^{7}\mathrm{Li}(^{90}\mathrm{Zr}, p3n)^{93m}\mathrm{Mo}$（非 $^{82}\mathrm{Se}+^{16}\mathrm{O}$）。Wu 2019 理论计算给出 $(2.26\text{--}2.73) \times 10^{-11}$。Guo 2022 在兰州 HIRFL / RIBLL 利用次级束流 $^{12}\mathrm{C}(^{86}\mathrm{Kr}, 5n)$ 产生 $460\ \mathrm{MeV}$ $^{93m}\mathrm{Mo}^{36+}$ 离子（非 ATLAS，纯度 $\sim 0.6\%$），在 $266.5\text{--}269.5\ \mathrm{keV}$ 窗测得 570 计数（本底 596 计数），以中心 $3\ \mathrm{keV}$ 窗所含高斯峰面积 $95\%$ 接受度导出上限 $P_{\mathrm{max}} \approx 2 \times 10^{-5}$（非 $95\%$ 置信水平）。该上限直接否定了该条件下的百分之一直径声称，但不同能量与电荷态条件不构成全物理平台排除。

## 5. 重离子完全熔合截面的三阶段解构与异能态脱耦

分波展开蒸发剩余截面：
$$
\sigma_{\mathrm{ER}}(E) = \sum_{J=0}^\infty \sigma_{\mathrm{cap}}(E, J) P_{\mathrm{CN}}(E, J) W_{\mathrm{sur}}(E^*, J).
$$
若 $\sigma_{\mathrm{cap}}(E, J)$ 已显式包含统计权重 $(2J+1)$，在求和中严禁重复乘入 $(2J+1)$。对于非零自旋体系，进入通道自旋平均因子为 $\frac{2J+1}{(2I_1+1)(2I_2+1)}$，求和遍历总自旋 $S$ 与轨道角动量 $l$。
- **俘获截面 $\sigma_{\mathrm{cap}}$**：近垒与次垒区受多道耦合（四极/十六极形变、表面振动、转移通道）支配，体现为多维势垒分布 $D(B)$。
- **复合核形成几率 $P_{\mathrm{CN}}$**：强依赖于体系质量不对称性与驱动势能面。轻中重体系接近 1；超重体系（$Z_1 Z_2 \gtrsim 1600\text{--}2000$）受强烈准裂变压制，可急剧降至 $10^{-2}\text{--}10^{-4}$ 或更低。不能无输入断言为全域常数或仅由 $Z_1 Z_2$ 判定。
- **存活几率 $W_{\mathrm{sur}}$**：统计模型乘积近似应表述为：
$$
W_{\mathrm{sur}}(E^*, J) \simeq \Delta_x(E^*, J) \prod_{k=1}^x \left[ \frac{\Gamma_n(E_k^*, J_k)}{\Gamma_{\mathrm{tot}}(E_k^*, J_k)} \right],
$$
其中 $\Delta_x$ 为能量实现因子（如 Jackson 因子，限定第 $x$ 步蒸发后剩余激发能落入裂变与粒子发射阈值之下的 $\gamma$ 能窗），避免与第 4.7 节 $\beta$ 缓发中子发射几率 $P_{xn}$ 混淆。
- **分宽量纲与公式核对**：Hauser-Feshbach 中子宽度与 Bohr-Wheeler 裂变宽度标准式为：
$$
\Gamma_n(E^*, J) = \frac{1}{2\pi \rho(E^*, J)} \sum_{J'} \sum_{l, j_n} \int_0^{E^* - S_n} T_l(\epsilon) \rho_R(E^* - S_n - \epsilon, J') d\epsilon,
$$
$$
\Gamma_f(E^*, J) = \frac{1}{2\pi \rho(E^*, J)} \int_0^{E^* - B_f(J)} \rho_{\mathrm{saddle}}(E^* - B_f(J) - \epsilon) d\epsilon.
$$
分子积分项为无量纲开放道数，除以母核能级密度 $\rho$（单位 $\mathrm{MeV}^{-1}$）后具有严格的能量量纲（$\mathrm{MeV}$）。严禁在 $T_l$ 积分前错误拼入多余的能量因子 $\epsilon$。
- **壳修正位垒阻尼**：基态微观壳修正 $\delta U_{\mathrm{gs}} < 0$ 增加束缚，对裂变位垒的微观增强为 $\Delta B_f^{\mathrm{shell}} \approx -\delta U_{\mathrm{gs}} > 0$。有效位垒随激发能阻尼表现为 $B_f(E^*) = B_f^{\mathrm{LD}} + \Delta B_f^{\mathrm{shell}} \exp(-\gamma_D E^*)$。Ignatyuk 能级密度参数阻尼为单粒子激发能阻尼，不直接等同于所有位垒均严格服从同式。
- **Xu 2004 机制辨析与异能态产生**：Xu 等人（2004）指出的超重核高 $K$ 异能态冷裂变位垒显著增高，属于冷态准粒子阻止效应。在复合核经历的前期高激发能蒸发阶段（$E^* \sim 30\text{--}50\ \mathrm{MeV}$），壳效应强烈阻尼，去激发由平均核能级密度和宏观竞争支配，冷态异能位垒不能直接代入；但中间级联降温与结构记忆仍可影响后期布居。最终异能态截面是进入态系综的加权积分：
$$
\sigma_{\mathrm{isomer}}(E) = \sum_J \sigma_{\mathrm{ER}}(E, J) b_{\mathrm{feed}}(E^*_{\mathrm{entry}}, J) \approx b_{\mathrm{eff}} \sigma_{\mathrm{ER}}.
$$
- **探测时间窗选择**：反冲飞行时间 $\tau_{\mathrm{TOF}} \sim 1\ \mu\mathrm{s}$ 导致超短寿命异能态在飞行中衰变损失（靶点瞬发 $\gamma$ 谱学除外）；极长寿命异能态超出采集时间窗 $\Delta T_{\mathrm{corr}}$ 无法关联。

## Assumptions

1. 天体辐射浴满足局部热力学平衡 Planck 谱；典型 $s$-过程环境假设中微子透明。
2. 双簇绝热消去假设中间桥态退激率远大于全簇宏观演化率。
3. 蒸发统计模型假定中子发射彼此独立，忽略两步相关的记忆效应。
4. 唯象壳阻尼模型假定壳修正随激发能单调指数衰减。

## Competing Explanations

1. $^{176}\mathrm{Lu}$ 热化：经典静态宇宙时钟假设 vs 高激发态共振光致退激加速假说。
2. $^{93m}\mathrm{Mo}$ NEEC 观测：反冲慢化 NEEC 假说（Chiara 2018）vs 熔合瞬发 $\gamma$ 本底/靶杂质污染竞争解释（Guo 2021）与次级异能束流微弱截面实验上限（Guo 2022）。
3. 超重核异能态稳定性：冷态高 $K$ 离散阻滞增高位垒（Xu 2004）vs 高温统计相空间中壳效应阻尼与中子/裂变竞争脱耦。

## Transfer Conditions

1. 开放速率网络与双簇特征值可平滑迁移至第 5.8 节异能态寿命与 feeding 测量模型。
2. 原子内转换通道电离关闭与晶格屏蔽可直接迁移至天体等离子体核合成网络与空间探测器环境分析。
3. 重离子熔合分波与存活公式可直接用于第 5.1 节在束核反应靶设计与截面预算。

## Failure Conditions

1. 将成对电磁可逆跃迁的详细平衡错误泛化为非平衡开放网络的全局 Boltzmann 分布。
2. 混淆核磁偶极算符的磁矩型与电荷型约定，对归一化无量纲 $b_{M1}$ 重复乘除光速 $c^2$。
3. 将宽禁带晶体对价层普通内转换的抑制误写为完全杜绝非辐射通道，或将折射率模型修正误写为真空直接测量。
4. 混淆 Chiara 2018（ATLAS, 7Li+90Zr）与 Guo 2022（HIRFL/RIBLL, 12C+86Kr）的实验装置与束流条件，或将 Guo 2022 中心窗高斯面积接受度 95% 误称为置信水平。
5. 在 Hauser-Feshbach 中子宽度积分中错误拼入多余动能因子 $\epsilon$，破坏宽度能量量纲。
6. 将零温冷态下离散高 $K$ 异能态的微观高位垒直接套用为高温复合核前几步蒸发阶段的存活几率。

## Falsification or Reverse Tests

1. 在 $T \to 0$ 极限下，Planck 占据数 $n_\gamma \to 0$，向上共振率 $\lambda_{l \to u} \to 0$，有效交换率 $a, b \to 0$，两簇特征值完全退化为独立的本征衰变率 $D_g$ 与 $D_m$。
2. 当入射角动量 $J$ 超出最高允许分波 $J_{\mathrm{fus}}^{\mathrm{max}}$ 时，势垒穿透几率 $T(E, J) \to 0$，俘获截面与蒸发截面严格截断为零。

## Open Questions

1. 极低激发能核态在非均匀纳米结构与极强外场耦合下的辐射--非辐射竞争相干调控。
2. 巨共振与高温高自旋复合核在准裂变临界点附近多维势能面上动力学输运张量的微观第一性原理自洽构建。

## Human Review

- 本研学笔记非人类专家人工审核（unreviewed），由智能体 G87 初建、G89 定点核验纠偏完成。

## Promotion or Rejection History

| Date | Event | Previous State | New State | Reason / Triggering Evidence | Target or Successor |
|---|---|---|---|---|---|
| 2026-11-13 | 建立第4.8节独占研学笔记 | none | provisional | 承接F06合同与39节架构，全面固化环境热浴、电子通道与重离子熔合三阶段证据链 | doctoral-nuclear-structure-foundations |
| 2026-11-13 | G89定点返修全节科学断言 | provisional | provisional | 响应父审意见：修正T8/T9同温区、光子占据数定义、详细平衡局域性、等于D时两簇弛豫率、消除M1光速混淆、纠正Th229原件独立测量与折射率模型、纠正Mo93原件反应/装置/束流纯度/95%高斯面积接受度定义、修正Gamma_n量纲与壳修正符号、澄清Xu2004冷热脱耦与探测时间窗 | doctoral-nuclear-structure-foundations |
