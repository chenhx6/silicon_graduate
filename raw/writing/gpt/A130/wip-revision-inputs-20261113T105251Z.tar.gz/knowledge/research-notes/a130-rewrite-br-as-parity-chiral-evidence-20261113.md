---
type: research-note
title: "A130重写：Br/As核区反射-手征谱学证据、网络拓扑与测量链辨析"
aliases: [br-as-parity-chiral-evidence, section-4-5-research-card]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
created_from: "父级派发第4.5节任务指令及刘晨2016、肖骁2019/2022原件实读核查"
promotion_target: ""
evidence_sources: [liu-chen-2016-78br-chirality-reflection-symmetry-thesis, liu-2016-octupole-correlations-multiple-chiral-doublet-bands-78br, xiao-xiao-2019-high-spin-74as-thesis, xiao-2022-chirality-octupole-correlations-74as]
tags: [doctoral-thesis, section-4-5, 78br, 74as, parity-doublets, chirality, octupole, d0-extraction]
---

# Br/As核区反射-手征证据链、实际网络拓扑与物理模型边界

## Research Trigger

在A≈80过渡质量区中，部分奇奇核（如78Br、74As）实验上观测到了正负宇称带之间的E1连接跃迁以及局域能级近简并现象。早期文献常将此类结构冠以“手征与空间反射对称性的联立自发破缺”或“四重手征-八极简并带（chiral-reflection quartet）”之名。然而，文献标题的命名不等于确凿的实验物理事实。

本笔记旨在为第4.5节建立严格的事实与方法论台阶：(1) 核查刘晨2016（78Br）与肖骁2019/2022（74As）真实观测到的能带网络与跃迁性质，澄清78Br中不同组态MchiD与四重简并带的本质区别，以及74As中负宇称伴带完全缺失（2+1结构）的实测事实；(2) 梳理内禀反射不对称与实验室好宇称态、反幺正算符C=TRy(pi)与幺正宇称P的理论区别；(3) 解剖内禀电偶极矩D0的真实测量反演链条，指明其强烈依赖于假定Q0的模型依赖属性；(4) 提出面向可证伪验证的高信息增益新实验候选方案。

## Grounded Evidence

| 证据来源 | 物理载荷与定位 | 适用边界与限制 |
|---|---|---|
| 刘晨 (2016 博士论文) & Liu et al. (PRL 2016) | 78Br中观测到5条带；Band 1,2为正宇称(pi g9/2 x nu g9/2)；Band 3,4为负宇称(pi f5/2 x nu g9/2)；8条E1跃迁仅连接Band 1与Band 3；PRL p. 3组态分配，p. 4 Fig. 5 B(E1)/B(E2)与delta E | 论文与PRL同属一次重离子在束实验采集；Band 2与Band 4之间无E1连接；两对带属于不同组态(MchiD)而非单一组态下空间反射破缺四重带；无绝对寿命测量 |
| 肖骁 (2019 硕士论文) & Xiao et al. (PRC 2022) | 74As中观测到3条带；Band 1,2为正宇称(pi g9/2 x nu g9/2)；Band 3为负宇称(pi (f5/2/p3/2) x nu g9/2)；3条E1连接Band 1与Band 3；PRC p. 4 Table I, p. 7 | 硕士论文与PRC同属一次74Ge(alpha, 1p3n)实验采集；负宇称伴带Band 4完全缺失(2+1结构)，不存在四重简并带；无绝对寿命测量 |
| Butler & Nazarewicz (Rev. Mod. Phys. 1996) | 内禀反射不对称与交替宇称能带理论；印页350–355 | 增强的E1跃迁受巨偶极共振(GDR)相干相消影响，不能作为静态八极形变的充分条件；弱E1亦不能排除八极关联 |
| Suhonen (2007) / Bohr-Mottelson II | 角动量张量代数与电磁跃迁算符定义；印页118–121 | 轴对称强耦合Clebsch-Gordan展开公式不适用于三轴K混合体系；无法由|D0|确定符号 |

## Provisional Reasoning

1. **实际观测网络与四重带假象的解耦**：
   实读原件表明，78Br中观测到的是两对不同组态的手征双重带候选（MchiD），正负宇称之间的8条E1连接仅发生在两对带中各自的最低序列（Band 1与Band 3）之间，未见Band 2与Band 4之间的E1跃迁；74As中则仅有正宇称双重带加上一条孤立的负宇称带，负宇称伴带缺失。绝不能将文献标题中的“四重带”当成四条严格简并且相互闭合连接的物理实体。

2. **反幺正时间反演-转动算符C与幺正宇称P的区别**：
   在手征对称性研究中，体系利用时间反演与绕特定体轴pi转动的复合算符 $C = \mathcal{T} \mathcal{R}_y(\pi)$ 描述手征变换。C是反幺正算符，满足 $C^2 = +1$，其本征值不能直接等同于空间坐标反演幺正算符 $\mathcal{P}$ 的本征值（宇称 $\pi = \pm 1$）。C对称性的存在并不强迫能带必须发生四重简并，且在一般三轴核中C并不是普遍守恒的好量子数。

3. **内禀电偶极矩D0的模型依赖性提取**：
   由实验测量无法直接“读出”内禀偶极矩 $D_0$。实验只能测量出两点各向异性比或分支比 $B(E1)/B(E2)$。在轴对称强耦合假设下，利用转动模型公式导出：
   $$D_0 = \sqrt{\frac{5}{16} \frac{B(E1; I \to I-1)}{B(E2; I \to I-2)} \frac{\langle I K 2 0 | I-2 K \rangle^2}{\langle I K 1 0 | I-1 K \rangle^2} Q_0^2}$$
   该提取链条高度依赖于所假定的内禀四极矩 $Q_0$（或理论模型计算的绝对 $B(E2)$）。在三轴形变且存在强烈K混合的奇奇核中，Clebsch-Gordan系数展开失去单K严格意义，$D_0$ 仅仅是一个反映相对强度的唯象衍生参量，绝非直接物理测量，且其代数正负号无法确定。

## Assumptions

- 假定实验给出的伽马射线能量、多极混合比分支比与各向异性比测量满足标准误差统计传播。
- 假定理论TPRM与MDC-CDFT计算中的形变参数（beta2, gamma）代表自洽变分极小。

## Competing Explanations

- **八极软度/八极振动 vs 稳定梨形形变**：E1跃迁的出现与能级位移delta E随自旋的演化，既可由动态八极振动与准粒子宇称混合解释，亦可由静态八极形变势阱解释；现有数据明显偏离稳定八极形变核（如224Th）的特征，更支持八极软度。
- **不同组态偶然近简并 vs 真手征双重带**：正负宇称带内部的能级伴带结构，既可能是非共面角动量几何产生的手征进动，也可能是单粒子组态交叉或普通未解对准粒子伴带的偶然近简并。

## Transfer Conditions

- 跨区迁移必须基于单粒子轨道费米面深度、对能隙大小与反应布居通道。从A≈80向A≈130或稀土区迁移时，轨道从p3/2-g9/2转变为d5/2-h11/2或f7/2-i13/2，必须重新核算单粒子能级劈裂与相互作用矩阵元。

## Failure Conditions

- 若在实际能谱中未观测到任何正负宇称连接的跃迁，却宣称确立了反射不对称性，则推断失效。
- 若将模型计算导出的D0当作实验直接测得的内禀电荷偶极矩进行多核比对，则违反测量链规范。

## Falsification or Reverse Tests

- **绝对寿命判决测试**：通过皮秒量级薄膜反冲距离法（RDM）直接测定78Br负宇称态与正宇称态的绝对寿命，给出绝对 $B(E1)$ 矩阵元；若绝对 $B(E1)$ 处于单粒子或受阻量级（$< 10^{-4}\,\mathrm{W.u.}$），则排除强相干集体八极增强机制。
- **高自旋伴带寻找**：在74As中利用更大立体角锗探测阵列提高统计量，寻找可能存在的负宇称伴带Band 4；若高统计下仍确认Band 4缺失，则彻底排除四重简并假设。

## Open Questions

- 在奇奇核复杂奇质子-奇中子残余相互作用下，三轴形变诱导的K混合如何定量改变内禀偶极矩的微观表象？
- 是否存在无需外加理论Q0输入、通过多极库仑激发直接独立提取偶极-八极跃迁矩阵元的实验方案？

## Human Review

- 2026-11-13：由G85依据刘晨2016与肖骁2019/2022原件实读建立研究笔记，严格排除非物理夸大断言。

## Promotion or Rejection History

- 2026-11-13：为第4.5节建立可复用L3研究卡，提供扎实的测量链与拓扑网络依据。
