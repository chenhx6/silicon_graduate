---
type: research-note
title: "A130重写研学：空间反射、手征对称性联立破缺与E1提取边界"
aliases: [A130 reflection chirality and E1 limits]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
created_from: "G81第3.7节起草、高风险合同F05审查及父审指导"
promotion_target: ""
evidence_sources: [liu-chen-2016-78br-chirality-reflection-symmetry-thesis, liu-2016-octupole-correlations-multiple-chiral-doublet-bands-78br, xiao-xiao-2019-high-spin-74as-thesis, book-bohr-mottelson-nuclear-structure-vol2, cline-1986-nuclear-shapes-coulomb-excitation]
tags: [A130, doctoral-thesis, octupole, reflection-asymmetry, chirality, E1-transitions, dipole-moment]
---

# 八极反射不对称、手征角动量几何与电偶极矩提取的模型边界

## Research Trigger

在第3.7节的起草与父审中，针对手征三轴与八极形变联立出现的物理问题确立了关键物理边界：
1. 八极自由度（$\beta_3, \mathcal{M}(E3)$）是 3 阶奇宇称张量；在全篇论文中，$q_3$ 严格代表由二阶电四极算符张量缩并构成的三次四极不变量（$q_3 \equiv -\sqrt{7/2} \langle (\hat{Q}_2 \times \hat{Q}_2)_2 \cdot \hat{Q}_2 \rangle = \langle Q^3 \cos 3\gamma \rangle$），具有 rank-0 标量与电荷长度量纲 $e^3\cdot\mathrm{fm}^6$，绝不能将 $q_3$ 混为 rank-2 或能量量纲，严禁重用指代八极形变；
2. 若 $\mathbf{j}_p, \mathbf{j}_n, \mathbf{R}$ 作用于不同子空间，标量三重积自身已具备厄米性；空间反演作为轴矢量变换严格保持标量积手征旋向，手征反转在核自旋体系中必须依赖包含时间反演的反幺正算符 $\mathcal{C} = \mathcal{T} R_y(\pi)$；
3. 空间反射与手征转动在动力学势能面上相互耦合，不必然在所有核中形成四个独立势阱；线性正交投影算符 $P^\pm = (\mathbf{1} \pm \hat{\Pi})/2$ 划分出的子空间相互正交（即使底层形变波包非正交）；$\mathcal{C}^2 = +1$ 不强迫克喇默斯简并，算符相容不等于有限核自动四倍简并；
4. $\Delta l = \Delta j = 3$ 是常见强相干驱动而非数学必要条件，$E3$ 算符在三角不等式与宇称定则下允许 $\Delta l = 1, 3$ 且 $\Delta j \le 3$；
5. 轻稀土区 Ba ($Z=56$) 由质子 $d_{5/2} \leftrightarrow h_{11/2}$ 与中子 $f_{7/2} \leftrightarrow i_{13/2}$ 驱动；锕系 Ra ($Z=88$) 由质子 $f_{7/2} \leftrightarrow i_{13/2}$ 与中子 $g_{9/2} \leftrightarrow j_{15/2}$ 驱动，不可混同；
6. 宏观液滴电荷位移与单粒子极化偶极的相消效应导致强 $E1$ 不唯一定静态 $\beta_3$，弱 $E1$ 亦不排除八极关联（如 $^{146}\mathrm{Ba}$ 反例）；转子模型 $|D_0|$ 提取可结合本核独立测定的 $Q_0$ 或 $B(E2)$，未测寿命时由分枝比仅能得 $|D_0/Q_0|$，绝不能虚构绝对 $|D_0|$；
7. 连接相反宇称能级的同一物理跃迁可发生 $E1 + M2$ 多极混合（物理多极混合），需与能谱中同宇称 $M1/E2$ 谱线的偶然探测重叠（实验 doublet 重叠）严格区分。

本页系统沉淀上述推导与证据边界，作为正文第3.7节与第4.5节的理论依据。

## Grounded Evidence

| 核心文献 / 本轮 locator | 载体路径与 SHA-256 | 支持主张与边界核定 |
|---|---|---|
| [[liu-chen-2016-78br-chirality-reflection-symmetry-thesis]]，PDF pp. 13–18, 78–82, 90 | `raw/theses/degree-dissertation/刘晨_奇奇核~(78)Br中手征...间反射对称性的联立自发破缺.pdf`<br>`5e00370aab205b689841cb58d65c7fad8829e3de74f084736a74f2d8658ab291` | 山东大学 2016 博士论文。第4章 $^{78}\mathrm{Br}$ 实验能级图、同宇称/相反宇称带间跃迁网络与八极软性势能面讨论；第5章展望强调需进一步寿命测量 |
| [[liu-2016-octupole-correlations-multiple-chiral-doublet-bands-78br]]，PDF pp. 1–6 | `raw/papers/2016_Liu et al_Evidence for Octupole Correlations in Multiple Chiral Doublet Bands.pdf`<br>`460051AED9AF9D84BBFA09A51339E4D671F8ABAAF511FF6B7E0A4FBC2A836AD4` | PRL 116, 112501 (2016)。$^{78}\mathrm{Br}$ 候选四重带能谱、带间 $E1$ 跃迁分枝比 $B(E1)/B(E2)$ 提取与反射不对称协变密度泛函理论对照 |
| [[xiao-xiao-2019-high-spin-74as-thesis]]，PDF pp. 43–49 | `raw/theses/degree-dissertation/肖骁_奇奇核~(74)As的高自旋态研究.pdf`<br>`bf0763004d98be5a540ab7802eb0baed7c11387224f1818426b891f5a3ef362b` | 山东大学 2019 硕士论文。第4章 $^{74}\mathrm{As}$ 激发带结构、八极跃迁网络排查与微观 TAC-RMF 势能面计算 |
| [[book-bohr-mottelson-nuclear-structure-vol2]]，PDF pp. 23–28 | `raw/books/nuclear structure Ⅱ_Bohr, Mottelson.pdf`<br>`46015a1401bcbdd40d4fd7267a1b066b4aef662050dcf35693e4e3a10a6d417a` | World Scientific 1998 再版。轴矢量反演性质、转子电磁跃迁几何选择定则与偶极矩内禀提取 |
| [[cline-1986-nuclear-shapes-coulomb-excitation]]，PDF pp. 685–692 | `raw/papers/gpt/learning-daily/20261022-DAY20-be2-qt-deformation-systematics/cline-1986-nuclear-shapes-coulomb-excitation.pdf`<br>`76d89a9bc5d603aa8dae104c0b6356271b7d152e0bff33e3cf78138861670113` | Ann. Rev. Nucl. Part. Sci. 36 (1986)。明确四极三次旋转不变量 $q_3 \equiv -\sqrt{7/2} \langle (\hat{Q}_2 \times \hat{Q}_2)_2 \cdot \hat{Q}_2 \rangle$ 为 rank-0 标量，严格由 rank-2 电四极算符构成，与电八极算符完全解耦 |

## Provisional Reasoning

### 1. 算符张量性质与解耦

定义必须清晰解耦：
- **四极三次不变量**：$q_3 \equiv -\sqrt{\frac{7}{2}} \langle (\hat{Q}_2 \times \hat{Q}_2)_2 \cdot \hat{Q}_2 \rangle = \langle Q^3 \cos(3\gamma) \rangle$，由 2 阶球张量算符缩并构成的 rank-0 标量不变量，具有正宇称与电荷长度量纲 $e^3\cdot\mathrm{fm}^6$，表征三轴四极不对称度；
- **八极算符**：$\hat{\mathcal{M}}(E3, \mu)$ 为 3 阶球张量算符，具有负宇称与电荷长度量纲 $e\cdot\mathrm{fm}^3$，表征空间反射不对称度。两者阶数、宇称与量纲完全不同。

在实验室系良宇称物理定态下，由于宇称选择定则：
$$
\langle \pi | \hat{\mathcal{M}}(E3, 0) | \pi \rangle \equiv 0.
$$
静态梨形形变绝不表现为实验室定态的静态八极矩，而表现为相反宇称态之间的强约化电八极跃迁 $B(E3)$。

### 2. 标量三重积变换性质

角动量为轴矢量：$\hat{\Pi} \hat{\mathbf{J}} \hat{\Pi}^{-1} = +\hat{\mathbf{J}}$，$\mathcal{T} \hat{\mathbf{J}} \mathcal{T}^{-1} = -\hat{\mathbf{J}}$。
标量三重积变换为：
$$
\hat{\Pi} \left[ \mathbf{j}_p \cdot (\mathbf{j}_n \times \mathbf{R}) \right] \hat{\Pi}^{-1} = + \mathbf{j}_p \cdot (\mathbf{j}_n \times \mathbf{R}),
$$
$$
\mathcal{T} \left[ \mathbf{j}_p \cdot (\mathbf{j}_n \times \mathbf{R}) \right] \mathcal{T}^{-1} = - \mathbf{j}_p \cdot (\mathbf{j}_n \times \mathbf{R}).
$$
空间反演保持角动量手征旋向，手征反转在核自旋体系中必须依赖包含时间反演的反幺正算符 $\mathcal{C} = \mathcal{T} R_y(\pi)$。三个角动量矢量非共面仅要求标量三重积非零，绝不要求三矢量处于严格 $90^\circ$ 正交。

### 3. 宇称正交性与手征反幺正性

线性正交投影算符 $P^\pm = (\hat{\mathbf{1}} \pm \hat{\Pi})/2$ 划分出的正负宇称子空间严格正交（$P^+ P^- = 0$；此时尽管底层的形变内禀波包 $|\Phi(\pm\beta_3)\rangle$ 存在非正交重叠，但投影后的物理子空间严格正交）。手征算符 $\mathcal{C} = \mathcal{T} R_y(\pi)$ 是反线性的，其与哈密顿量对易 $[\hat{H}, \mathcal{C}] = 0$ 依赖全空间旋转不变性。由于 $\mathcal{C}^2 = +1 \ne -1$，体系不受克喇默斯定理强制简并保护，算符相容不等于有限核自动四重简并。

### 4. 内禀电偶极矩 $|D_0|$ 提取的模型假定

在强耦合近轴对称转子模型下：
$$
B(E1; I \to I-1) = \frac{3}{4\pi} D_0^2 \, (I \, 1 \, K \, 0 | I-1 \, K)^2.
$$
局限与边界：
1. 实验测得退激发分枝比 $B(E1)/B(E2)$ 在缺乏能级寿命时，只能提取比值 $|D_0 / Q_0|$，不能提取绝对 $|D_0|$；可结合同核独立测定的 $Q_0$ 进行换算，不必须依赖未标定理论；
2. 比值公式含平方项，无法确定 $D_0$ 的物理正负符号；
3. 在三轴非轴对称核中，偶极矩在主轴系有多个分量（$D_0, D_1$），单一分支反演非唯一；
4. 宏观液滴电荷位移与单粒子极化偶极的相消效应导致 $|D_0|$ 异常微弱不能作为排除八极形变的依据；
5. 在连接相反宇称能级之间的一条物理跃迁内部允许发生 $E1 + M2$ 多极混合，须与实验谱线双峰重叠（如 $E1$ 与同宇称 $M1/E2$ 重叠）严格区分。

## Assumptions

1. 体系全核相互作用哈密顿量满足严格的空间反演守恒 $[\hat{H}, \hat{\Pi}] = 0$、时间反演守恒与空间连续转动不变性；
2. 手征非共面矢量耦合假定存在三个非零角动量分量（标量三重积非零），不要求三矢量处于严格 $90^\circ$ 正交；
3. 转子偶极矩公式假定内禀投影 $K$ 良好且强耦合近似成立。

## Competing Explanations

1. **静态八极反射破缺 vs. 动态八极表面振动**：大多数原子核沿 $\beta_3$ 势面平坦无深阱，相反宇称带更普遍由动态八极声子激发主导；
2. **手征—八极四重带 vs. 准粒子顺排带交叉**：奇奇核中高自旋多准粒子交叉交错可表观模仿四带近简并能谱；
3. **物理多极混合 ($E1+M2$) vs. 谱线偶然重叠**：弱偶极跃迁若未经偏振度检验，可能存在多极混合或谱线混叠。

## Transfer Conditions

1. **算符与不变量分离**：$q_3$ 严格作为 rank-0 四极标量不变量使用，八极分析必须使用独立的 3 阶算符 $\beta_3$ 与 $B(E3)$；
2. **实验室良量子数守恒**：内禀四势阱图像必须通过线性的宇称投影算符与广义本征方程在实验室系恢复良自旋宇称态；
3. **$D_0$ 提取必须申明采用输入**：若无绝对寿命测量，必须显式声明所采用的同核独立四极矩或理论模型假设，不作为独立实测绝对值。

## Failure Conditions

1. 若将 $q_3$ 误记为八极形变或八极跃迁量，则会导致张量阶数与物理量纲全面混乱；
2. 若误以为空间反演可以反转角动量标量三重积，则违背轴矢量基本对称性；
3. 若根据 $[\hat{H}, \hat{\Pi}] = 0$ 和 $[\hat{H}, \mathcal{C}] = 0$ 断言有限核中必然出现严格四重简并，则混淆了反幺正算符与克喇默斯定理；
4. 若将偶偶核 $K=0$ 交替宇称带与奇奇核四重候选带混同，则混淆了玻色核芯与费米准粒子结构；
5. 若在缺乏寿命测量的核素中虚构绝对 $|D_0|$ 数值，则违背实验可追溯性底线。

## Falsification or Reverse Tests

1. **$^{146}\mathrm{Ba}$ 极化相消反例**：该核具有明确的八极形变 $\beta_3$，但由于单粒子极化偶极矩与液滴偶极矩发生强烈反向相消，测得的内禀偶极矩被显著压低，有力推翻了“弱 $E1$ 必然对应无八极形变”的直观假设；
2. **$^{78}\mathrm{Br}$ 候选四带实验再检验**：刘晨 2016 博士论文与 Liu 2016 PRL 报告了 $^{78}\mathrm{Br}$ 中的交叉跃迁网络，但明确指出由于缺乏全套带间能级寿命测量与绝对 $B(E3)$ 数据，四重态的完全确立仍面临微观软核与组态杂化的理论反方检验，未作排他性终结宣称。

## Open Questions

1. **三轴非轴对称势面下多重偶极分量 $(D_0, D_1)$ 的自洽微观提取**：在偏离轴对称时，宏观流体与微观极化偶极的张量展开算法仍待进一步自洽密度泛函量化；
2. **四重态量子隧穿势垒高度对正负宇称能级劈裂差异的微观调控**：正宇称与负宇称手征双带能隙 $\Delta E^+ \ne \Delta E^-$ 的微观壳驱动机制仍需大尺度组态相互作用检验。

## Human Review

本研究笔记内容基于 G81 自主推导、高风险合同 F05 原件核查及父审指导完成，属于纯 Agent 内部交叉核算与学术沉淀。
截至 2026-11-13，本页无真实用户人工审核事件。
依据本知识库工作约定，`review_status: unreviewed` 仅记录审核历史状态，不作发布级认证，客观科学有效性由 Agent 根据直接推导与文献原件证据自主判定。

## Promotion or Rejection History

- 2026-11-13：由 G81 在完成第 3.7 节起草后正式建档，沉淀八极反射不对称与四极不变量严格解耦、标量三重积变换性质、线性宇称与反幺正手征代数对立，以及内禀电偶极矩 $|D_0|$ 提取模型假定的完整理论边界。
- 2026-11-13：按父审增量指示，修正 canonical 来源键为 liu-2016-octupole-correlations-multiple-chiral-doublet-bands-78br，严格规范 q3 标量不变量定义与量纲，区分轴矢量独立因子对易与厄米性，补全 Delta l = 1, 3 允许跃迁，校准轻稀土 Ba 与锕系 Ra 的不同微观轨道对，完善 E1+M2 多极混合与 doublet 重叠区分。
