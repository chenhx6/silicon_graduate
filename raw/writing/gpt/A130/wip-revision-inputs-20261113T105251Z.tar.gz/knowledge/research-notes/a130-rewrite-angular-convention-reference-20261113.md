---
type: research-note
title: "A130重写研学：角动量耦合、不可约球张量与形状不变量重耦合参考"
aliases: [A130 angular momentum recoupling and tensor conventions]
created: 2026-11-13
updated: 2026-11-13
status: ai-draft
review_status: unreviewed
reasoning_status: provisional
created_from: "针对附录A角动量代数、Wigner-Eckart规范、6j重耦合与单位制相位的严格数学支撑"
promotion_target: ""
evidence_sources: [book-suhonen-from-nucleons-to-nucleus, cline-1986-nuclear-shapes-coulomb-excitation, poves-2020-limits-assigning-nuclear-shape, lange-kumar-hamilton-1982-multipole-admixtures]
tags: [A130, doctoral-foundations, angular-momentum, wigner-eckart, racah-algebra, 6j-symbols, shape-invariants, multipole-mixing-ratio]
---

# 角动量代数、张量归约与不变量重耦合规范

## Research Trigger

在全篇博士论文中，不可约球张量代数、约化矩阵元（RME）相位规范、形状不变量（$q_2, q_3$）的完备态求和以及多极混合比 $\delta(E2/M1)$ 跨越了第2.1节、第2.7节、第5.7节与第5.9节。不同文献在角动量代数定义、相位约定与电磁单位上存在大量隐性分歧（如 CS 与 BR 相位、高斯制与 SI 制磁矩定义）。本笔记旨在系统梳理严格的 Racah 代数推导步骤、统一符号量纲与极限检验，为附录 A 提供严格自洽的数学支撑。

## Grounded Evidence

| 依赖与本轮核读 locator | 实际载体和核验 | 支持范围及证据身份 |
|---|---|---|
| [[book-suhonen-from-nucleons-to-nucleus]]，第 1–2 章印刷 pp. 11–45（PDF pp. 26–60），第 6 章印刷 pp. 117–137（PDF pp. 132–152） | `raw/books/From nucleons to nucleus concepts of microscopic .pdf`；SHA-256 `4d4b799b8d91784638bac29e0749fe08ba9720f067fd76317f7e256d6f8cd27c` | Wigner-Eckart 定理标准式 (2.24)；球张量厄米共轭式 (2.15)；$6j$ 符号求和与复合张量重耦合式 (2.47)–(2.55)；电磁多极算符定义与 CS/BR 相位转换式 (6.4)–(6.11)。 |
| [[cline-1986-nuclear-shapes-coulomb-excitation]]，印刷 pp. 698–700（PDF pp. 16–18） | 库仑激发不变量专著选读 | 库仑激发多步矩阵元闭合环路乘积与旋转不变量 $q_2, q_3$ 的标量积定义及有限截断几何解释。 |
| [[poves-2020-limits-assigning-nuclear-shape]]，实际 v2 PDF pp. 2–6，Eqs.(3)–(17) | 现代核形状不变量检验文献 | 澄清矩比 $q_3/q_2^{3/2}$ 与 $\cos 3\gamma$ 无权平均的本质区别，给出有限涨落下的模型反例。 |
| [[lange-kumar-hamilton-1982-multipole-admixtures]]，印刷 pp. 121–122 | 多极混合比综述选读 | 光子多极混合比 $\delta(E2/M1)$ 无量纲比值定义、辐射场相位与在束角分布反演约定。 |

## Provisional Reasoning

1. **Wigner-Eckart 定理与约化矩阵元（RME）逆序相位：**
   全篇统一采用第 2.1 节与 Suhonen 式 (2.24) 的标准定义：
   $$
   \langle j_f m_f | T_{\lambda\mu} | j_i m_i \rangle = (-1)^{2\lambda} \frac{C_{j_i m_i \lambda\mu}^{j_f m_f}}{\sqrt{2j_f + 1}} \langle j_f || T_\lambda || j_i \rangle.
   $$
   当张量算符满足厄米性条件 $T_{\lambda\mu}^\dagger = (-1)^\mu T_{\lambda,-\mu}$ 时，利用 Clebsch-Gordan 系数的对称性，约化矩阵元的逆序复共轭满足：
   $$
   \langle j_i || T_\lambda || j_f \rangle^* = (-1)^{j_f - j_i} \langle j_f || T_\lambda || j_i \rangle.
   $$
   若在实数基底下矩阵元为实数，则 $R_{if} = (-1)^{j_f - j_i} R_{fi}$。这一逆序变号在电四极跃迁（$\lambda=2$ 为偶数，故 $(-1)^{2\lambda}=1$）中决定了上行与下行约化跃迁几率的统计权重比：
   $$
   B(E\lambda; I_i \to I_f) = \frac{1}{2I_i + 1} |R_{fi}|^2 \implies B(E\lambda; I_f \to I_i) = \frac{2I_i + 1}{2I_f + 1} B(E\lambda; I_i \to I_f).
   $$

2. **静四极矩 $Q_s(I)$ 的对角选择定则与极小自旋限制：**
   实验室静四极矩定义为电四极张量零分量在最大子态 $M=I$ 上的期望值：
   $$
   Q_s(I) \equiv \sqrt{\frac{16\pi}{5}} \langle I, I | \mathcal{M}(E2, 0) | I, I \rangle = \sqrt{\frac{16\pi}{5}} \begin{pmatrix} I & 2 & I \\ -I & 0 & I \end{pmatrix} \langle I || \mathcal{M}(E2) || I \rangle.
   $$
   三角不等式条件 $\Delta(I, 2, I)$ 严格要求：
   - 当 $I = 0$ 时，$\begin{pmatrix} 0 & 2 & 0 \\ 0 & 0 & 0 \end{pmatrix} = 0$，故 $0^+$ 态的静四极矩恒等于零：$Q_s(0) \equiv 0$；
   - 当 $I = 1/2$ 时，$2I = 1 < 2$，无法满足三角条件，故自旋 $1/2$ 态的静四极矩严格恒等于零：$Q_s(1/2) \equiv 0$；
   - 只有当 $I \ge 1$ 时，$Q_s(I)$ 方可非零。

3. **复合张量重耦合与三阶形状不变量 $q_3$ 的一般自旋展开：**
   二阶形状不变量定义为标量积期望值：$q_2 = \langle T \cdot T \rangle_s = \frac{1}{2I_s + 1} \sum_r |R_{sr}|^2$。
   三阶不变量算符定义为：$\hat{B} \equiv -\sqrt{\frac{35}{2}} \bigl[ [T \times T]^2 \times T \bigr]^0$。
   利用两体复合不可约球张量的重耦合定理（Suhonen 式 2.47 与 2.50）：
   $$
   \langle I_s || [T_{\lambda_1} \times T_{\lambda_2}]^\lambda || I_t \rangle = (-1)^{I_s + I_t + \lambda} \sqrt{2\lambda + 1} \sum_r \begin{Bmatrix} \lambda_1 & \lambda_2 & \lambda \\ I_t & I_s & I_r \end{Bmatrix} \langle I_s || T_{\lambda_1} || I_r \rangle \langle I_r || T_{\lambda_2} || I_t \rangle.
   $$
   将 $\hat{B}$ 的零耦合期望值在一般初态 $|I_s\rangle$ 上展开，插入中间态完备集 $|r\rangle, |t\rangle$：
   $$
   q_3(I_s) = -\sqrt{\frac{7}{2}} \frac{1}{2I_s + 1} \sum_{r, t} (-1)^{2I_s + I_r + I_t} \begin{Bmatrix} 2 & 2 & 2 \\ I_r & I_t & I_s \end{Bmatrix} R_{sr} R_{rt} R_{ts}.
   $$
   对于偶偶核 $0^+$ 基态（$I_s = 0$），中间态自旋受约束为 $I_r = I_t = 2$，代入特殊 $6j$ 符号 $\begin{Bmatrix} 2 & 2 & 2 \\ 2 & 2 & 0 \end{Bmatrix} = \frac{1}{5}$，立即退化为第 2.1 节式 (2.1.28) 的基态最小解析式：
   $$
   q_3(0^+) = -\sqrt{\frac{7}{10}} \sum_{r, t} R_{0r} R_{rt} R_{t0}.
   $$

4. **电磁单位映射与多极混合比 $\delta(E2/M1)$：**
   - 电多极算符 $\mathcal{M}(E\lambda, \mu)$：单位 $e\cdot\mathrm{fm}^\lambda$，$B(E\lambda)$ 单位 $e^2\cdot\mathrm{fm}^{2\lambda}$；
   - 磁偶极算符 $\mathcal{M}(M1, \mu)$：传统单位采用核磁子 $\mu_N = \frac{e\hbar}{2m_p}$（SI 制），$B(M1)$ 单位为 $\mu_N^2$；Suhonen 体系定义提取了 $1/c$，使其量纲为 $\mu_N/c$，但两者在物理辐射率计算中完全等价；
   - 多极混合比 $\delta(E2/M1)$ 是无量纲辐射发射振幅之比：
     $$
     \delta(E2/M1) = \frac{\sqrt{3}}{10} \frac{E_\gamma}{\hbar c} \frac{\langle I_f || \mathcal{M}(E2) || I_i \rangle}{\langle I_f || \mathcal{M}(M1) || I_i \rangle}.
     $$

5. **DCO 比值二次有理方程与多极混合比反演结构（服务于第 3.4 节与第 5.7 节）：**
   - 在束 $\gamma$ 谱学中，方向角关联比值 $R_{\text{DCO}}$ 是初态取向张量 $B_k(I_i)$、几何角分布系数 $F_k$ 与多极混合比 $\delta(E2/M1)$ 的函数。由于辐射发射强度正比于多极展开项模平方，角分布展开系数表现为 $A_k(\delta) = \frac{B_k(I_i) [F_k(L L I_f I_i) + 2\delta F_k(L L\x27 I_f I_i) + \delta^2 F_k(L\x27 L\x27 I_f I_i)]}{1 + \delta^2}$，使实测 DCO 比值 $R_{\text{DCO}}(\delta) = W(\theta_1, \theta_2, \phi; \delta) / W(\theta_2, \theta_1, \phi; \delta)$ 构成了关于 $\delta$ 的二次有理分式方程；
   - 求解代数方程 $R_{\text{DCO}}(\delta) = R_{\text{exp}}$ 在实数域内一般给出两实数根、单重根（极大/极小极值处）或无实解（实测值超出几何可达区间），并非恒定存在“一显著大根与一显著小根”；
   - 康普顿线偏振度 $P$ 测量引入关于电四极与磁偶极的宇称鉴别，但在偏振灵敏度有限或两根理论预测接近时，不保证能绝对消除多解性；
   - 必须严格以辐射几率振幅之比定义 $\delta(E2/M1)$，保持带量纲电磁算符因子与光子能量因子的自洽性，不可随意替换为裸约化矩阵元比值。

## Assumptions

- 角动量态基矢严格正交归一，具有良好的自旋 $I$ 与磁量子数 $M$；
- 多粒子波函数在纯三维旋转群 $\mathrm{SO}(3)$ 下满足不可约球张量变换；
- 完备集闭合求和假定中间态空间具有酉度规。

## Competing Explanations

- **相位自由度与可观测闭环：** 单个非对角约化矩阵元 $R_{ab}$ 的正负符号取决于人为选定的基矢相位定义，不具备独立的物理可观测性；只有对角矩阵元 $R_{aa}$（如静四极矩 $Q_s$）以及沿闭合环路相乘的干涉积 $\prod R_{ij}$ 才是严格规范不变的可观测量。
- **几何有效角解释的不确定性：** 矩比 $q_3/q_2^{3/2}$ 并不保证数学上严格落在有效实角 $\cos 3\gamma_{\mathrm{eff}}$ 的实数域内，也不能直接判定核是处于刚性三轴极小点还是具有强烈的动力学软振动涨落。

## Transfer Conditions

本笔记提供的数学推导直接服务于正文第 2.1 节（形状不变量）、第 2.7 节（有效算符）、第 3.4 节（进动、TiP与电磁多极判据）、第 5.7 节（角分布反演）与第 5.9 节（绝对跃迁几率）；不作为独立实验结论。

## Failure Conditions

- 将电四极算符的共轭关系套用到电荷改变弱跃迁算符（如 Gamow-Teller $\hat{\beta}_\pm$）上；
- 将 $0^+$ 态的静四极矩 $Q_s(0)=0$ 误解为原子核处于球形（$Q_s$ 为零是角动量三角选择定则的纯几何结果，形变转子的 $Q_0 \ne 0$ 在实验室系由于空间各向同性平均而给出 $Q_s(0)=0$）；
- 忽略不同物理量纲直接对比不同作者的磁偶极矩阵元。

## Falsification or Reverse Tests

- 在库仑激发多态分析中，改变任意能级的人为相位角 $\phi_a$，检验闭合环路乘积与计算截面是否保持完全不变；
- 利用代数求和规则检验 $q_2 = \sum_r B(E2; s \to r)$ 与直接数值对角化积分是否严格吻合。

## Open Questions

- 在大尺度非对称核或微观三轴超形变带中，高阶形状不变量（如四阶与六阶不变量）对有限中间态截断误差的非线性敏感度。

## Human Review

本笔记由智能体基于标准角动量理论专著与形状不变量权威文献梳理建立，不包含虚构个人数据；未进行真实用户审核。
- 2026-11-13（G88）：补充第 3.4 节所需 DCO 二次有理分式结构、多极混合比辐射振幅量纲规范及偏振度消除多解性边界条件；保持原有 evidence_sources 与 unreviewed 科学状态。

## Promotion or Rejection History

- 2026-11-13：根据附录 A 任务要求建立，作为角动量 Racah 代数与张量归约的核心理论支撑。
