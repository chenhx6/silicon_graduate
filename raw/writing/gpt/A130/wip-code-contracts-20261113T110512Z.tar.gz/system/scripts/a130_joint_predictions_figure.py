# system/scripts/a130_joint_predictions_figure.py
# Generates joint predictions and complementary observables workflow for Section 3.8
import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

os.makedirs('raw/writing/gpt/A130/these_2023_template/these_template/Img', exist_ok=True)

fig, ax = plt.subplots(figsize=(8.2, 5.2), dpi=300)
ax.set_xlim(0, 10)
ax.set_ylim(0, 7)
ax.axis('off')

ax.text(5.0, 6.6, "Joint Predictions and Complementary Observables Framework", 
        ha='center', va='center', fontsize=12.5, fontweight='bold', color='#1A237E')

rect1 = patches.FancyBboxPatch((0.5, 4.4), 9.0, 1.8, boxstyle="round,pad=0.2", 
                               edgecolor='#303F9F', facecolor='#E8EAF6', lw=1.5)
ax.add_patch(rect1)
ax.text(0.8, 5.9, "I. Theoretical Forward Model Space (Declared Inputs & Coordinates)", 
        fontsize=10.5, fontweight='bold', color='#1A237E')
ax.text(1.0, 5.4, "- Coordinates & Truncations: Euler angles (orientation) vs. Bohr (beta, gamma) vs. Quasi-particles", fontsize=9)
ax.text(1.0, 5.0, "- Inputs: Phenomenological or self-consistent PES, Microscopic inertia J(w), Pairing Delta, Effective operators", fontsize=9)
ax.text(1.0, 4.6, "- Boundaries: Model labels are NOT observables; Wavefunction trajectories belong to specific model representations", fontsize=9)

rect2 = patches.FancyBboxPatch((0.5, 2.2), 9.0, 1.8, boxstyle="round,pad=0.2", 
                               edgecolor='#00796B', facecolor='#E0F2F1', lw=1.5)
ax.add_patch(rect2)
ax.text(0.8, 3.7, "II. Complementary Observable Channels (Holdout Validation with Covariance)", 
        fontsize=10.5, fontweight='bold', color='#004D40')

box_props = dict(boxstyle='square,pad=0.3', facecolor='#B2DFDB', edgecolor='#00796B', lw=1)
ax.text(1.8, 3.0, "Energy Levels\nAvoided crossing\nLevel repulsion", ha='center', va='center', fontsize=8.5, bbox=box_props)
ax.text(4.0, 3.0, "Absolute Rates\nB(EL) proportional to 1/tau\nBranching covariance", ha='center', va='center', fontsize=8.5, bbox=box_props)
ax.text(6.2, 3.0, "Angular & Polariz.\nMultiple delta branches\nLinear polariz. P", ha='center', va='center', fontsize=8.5, bbox=box_props)
ax.text(8.4, 3.0, "High-Spin Align.\nAlign. momentum ix\nBand crossings", ha='center', va='center', fontsize=8.5, bbox=box_props)

rect3 = patches.FancyBboxPatch((0.5, 0.2), 9.0, 1.6, boxstyle="round,pad=0.2", 
                               edgecolor='#D32F2F', facecolor='#FFEBEE', lw=1.5)
ax.add_patch(rect3)
ax.text(0.8, 1.5, "III. Falsifiable Empirical Candidates (Direct Discriminative Paths)", 
        fontsize=10.5, fontweight='bold', color='#B71C1C')
ax.text(1.0, 1.1, "1. 98Mo Octupole: Weak E3 links (1833.3 keV 5- -> 2+, 1585.8 keV 7- -> 4+); Need independent lifetime & feeding study", fontsize=8.2)
ax.text(1.0, 0.75, "2. 102Ru Dipole: E1 clustering at 2.95 MeV (B(E1)=0.016 e^2 fm^2); E1 selection rules from 0+ to 1- (E3 excites 3-)", fontsize=8.2)
ax.text(1.0, 0.4, "3. A~130 Low-Spin Orientation: 135Pr dual delta roots (|delta|<1 vs |delta|>1), B(E2;747)/B(E2;526)=0.7, QTR vs. IBFM", fontsize=8.2)

arrow_props = dict(facecolor='#37474F', edgecolor='#37474F', width=1.5, headwidth=6, shrink=0.05)
ax.annotate('', xy=(5.0, 4.4), xytext=(5.0, 4.1), arrowprops=arrow_props)
ax.annotate('', xy=(5.0, 2.2), xytext=(5.0, 1.9), arrowprops=arrow_props)

plt.tight_layout()

pdf_path = 'raw/writing/gpt/A130/these_2023_template/these_template/Img/joint-predictions-workflow.pdf'
svg_path = 'raw/writing/gpt/A130/these_2023_template/these_template/Img/joint-predictions-workflow.svg'
plt.savefig(pdf_path)
plt.savefig(svg_path)
plt.close()
print("Saved figure successfully.")
