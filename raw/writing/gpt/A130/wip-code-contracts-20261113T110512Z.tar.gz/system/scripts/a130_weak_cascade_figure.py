#!/usr/bin/env python3
"""
Pedagogical illustration of beta-delayed feeding and gamma/n statistical cascade competition.
Not an experimental spectrum; schematic physics model for Section 4.7.2.
"""
import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def generate_figure():
    out_dir = 'raw/writing/gpt/A130/these_2023_template/these_template/Img'
    os.makedirs(out_dir, exist_ok=True)

    plt.rcParams['font.family'] = 'DejaVu Sans'
    plt.rcParams['mathtext.fontset'] = 'cm'

    fig, ax = plt.subplots(figsize=(8.8, 5.4), dpi=300)
    ax.set_xlim(-0.5, 10.5)
    ax.set_ylim(-0.5, 10.5)
    ax.axis('off')

    # Parent nucleus (Z, N) on the left
    ax.plot([0.5, 2.5], [8.5, 8.5], color='#1f77b4', lw=3)
    ax.text(1.5, 8.8, r'Parent $(Z, N)$', ha='center', va='bottom', fontsize=11.5, fontweight='bold', color='#1f77b4')
    ax.text(1.5, 8.1, r'$J_i^\pi, \text{gs}$', ha='center', va='top', fontsize=10)

    # Q_beta arrow down to daughter ground state
    ax.annotate('', xy=(3.8, 1.0), xytext=(1.5, 8.0),
                arrowprops=dict(arrowstyle="->", color='#7f7f7f', lw=1.5, ls='--'))
    ax.text(2.3, 4.8, r'$\beta^-$ decay' + '\n' + r'$Q_\beta \approx 8.5\text{ MeV}$' + '\n' + r'($T_{1/2}^\beta \sim \text{ms--s}$)',
            ha='center', va='center', fontsize=9.5, color='#333333',
            bbox=dict(boxstyle="round,pad=0.3", fc="#f0f0f0", ec="#cccccc", lw=1))

    # Daughter nucleus (Z+1, N-1) in the center
    # Ground state
    ax.plot([4.0, 7.0], [1.0, 1.0], color='#2ca02c', lw=3)
    ax.text(5.5, 0.6, r'Daughter $(Z+1, N-1)$ Ground State', ha='center', va='top', fontsize=11, fontweight='bold', color='#2ca02c')

    # Low-lying discrete states below S_n
    for ey in [1.8, 2.6, 3.4]:
        ax.plot([4.2, 6.8], [ey, ey], color='#555555', lw=1.2)
        ax.annotate('', xy=(5.5, 1.0), xytext=(5.5, ey),
                    arrowprops=dict(arrowstyle="->", color='#e377c2', lw=1.2))

    # Sn threshold line
    ax.plot([3.8, 7.2], [4.5, 4.5], color='#d62728', lw=2, ls=':')
    ax.text(7.3, 4.5, r'$S_n$ (Neutron Separation Threshold)', ha='left', va='center', fontsize=10, fontweight='bold', color='#d62728')

    # High-lying continuum / resonance states above S_n
    for ey in [5.3, 6.2, 7.1, 8.0]:
        ax.plot([4.2, 6.8], [ey, ey], color='#555555', lw=1.2)
        # Competing gamma decay to lower states
        ax.annotate('', xy=(4.8, 2.6), xytext=(4.8, ey),
                    arrowprops=dict(arrowstyle="->", color='#e377c2', lw=1.0, ls='-.'))
        # Competing neutron emission to granddaughter
        ax.annotate('', xy=(8.2, ey - 4.5 + 2.0), xytext=(6.5, ey),
                    arrowprops=dict(arrowstyle="->", color='#ff7f0e', lw=1.5))

    # Shaded region above S_n indicating competition window
    rect = patches.Rectangle((4.0, 4.5), 3.0, 4.3, linewidth=0, edgecolor='none', facecolor='#fee8c8', alpha=0.4)
    ax.add_patch(rect)
    ax.text(5.5, 8.5, r'Energy Window $Q_\beta - S_n$' + '\n' + r'$\Gamma_\gamma \text{ vs } \Gamma_n \text{ Incoherent Competition}$',
        ha='center', va='center', fontsize=9.5, color='#d95f02', fontweight='bold',
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#d95f02", lw=1))

    # Granddaughter nucleus (Z+1, N-2) on the right
    ax.plot([8.0, 9.8], [2.0, 2.0], color='#9467bd', lw=3)
    ax.text(8.9, 1.6, r'Granddaughter $(Z+1, N-2)$' + '\n' + r'Ground State', ha='center', va='top', fontsize=11, fontweight='bold', color='#9467bd')

    for gy in [3.0, 3.8]:
        ax.plot([8.2, 9.6], [gy, gy], color='#777777', lw=1.2)

    # Explanation text box
    ax.text(1.2, 2.2, r'$\beta$-Feeding Intensity $I_\beta(i)$ ($\sum_i I_\beta = 100\%$)' + '\n' +
            r'Cascade Net Probability:' + '\n' +
            r'$P_{1n} = \sum_{E_x(i) > S_n} I_\beta(i) \, \Pi_1(i)$' + '\n' +
            r'Prompt $\Gamma_\gamma / \Gamma_n$ step relative to parent $T_{1/2}^\beta$',
            ha='left', va='center', fontsize=9.0,
            bbox=dict(boxstyle="round,pad=0.4", fc="#f7f7f7", ec="#999999", lw=1))

    ax.plot([], [], color='#e377c2', lw=1.5, label=r'$\gamma$-Ray De-excitation ($\Gamma_\gamma$)')
    ax.plot([], [], color='#ff7f0e', lw=2.0, label=r'Delayed Neutron Emission ($\Gamma_n$)')
    ax.legend(loc='upper right', frameon=True, fontsize=9.5)

    plt.tight_layout()
    svg_path = os.path.join(out_dir, 'weak-cascade-competition.svg')
    pdf_path = os.path.join(out_dir, 'weak-cascade-competition.pdf')
    fig.savefig(svg_path, format='svg')
    fig.savefig(pdf_path, format='pdf')
    plt.close(fig)
    print(f"Generated {svg_path} and {pdf_path}")

if __name__ == '__main__':
    generate_figure()
