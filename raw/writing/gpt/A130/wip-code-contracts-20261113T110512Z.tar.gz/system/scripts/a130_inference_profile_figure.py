#!/usr/bin/env python3
"""
a130_inference_profile_figure.py
Didactic model of profile likelihood bimodal profile and boundary constraint.
Generates Img/inference-profile-likelihood-boundary.svg and Img/inference-profile-likelihood-boundary.pdf.
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os
import hashlib

def main():
    img_dir = 'raw/writing/gpt/A130/these_2023_template/these_template/Img'
    os.makedirs(img_dir, exist_ok=True)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.8), dpi=300)

    theta_delta = np.linspace(-85, 85, 400)
    chi2_bimodal = 8.0 * np.sin(np.radians(theta_delta - 10))**2 + 4.0 * np.cos(np.radians(2*theta_delta + 30))**2 - 1.5
    chi2_bimodal -= np.min(chi2_bimodal)

    ax1.plot(theta_delta, chi2_bimodal, color='#1f77b4', lw=2.0, label=r'Profile Likelihood $-2\Delta\ln\mathcal{L}$')
    th_min1 = -35.0
    parabola = 0.015 * (theta_delta - th_min1)**2
    ax1.plot(theta_delta, parabola, color='#d62728', ls='--', lw=1.5, label=r'Local Parabolic (Hessian) Approx.')

    ax1.axhline(1.0, color='gray', ls=':', lw=1.0)
    ax1.text(-80, 1.2, r'$1\sigma$ Line ($\Delta\chi^2 = 1$, 1 DOF)', fontsize=8.5, color='gray')
    ax1.axhline(3.84, color='gray', ls=':', lw=1.0)
    ax1.text(-80, 4.04, r'$95\%$ Line ($\Delta\chi^2 = 3.84$, 1 DOF)', fontsize=8.5, color='gray')

    ax1.set_xlabel(r'$\arctan\delta$ (degrees)', fontsize=10)
    ax1.set_ylabel(r'$\Delta\chi^2(\delta) = -2\Delta\ln\mathcal{L}$', fontsize=10)
    ax1.set_title(r'(a) Bimodal Likelihood Profile vs False Local Gaussian', fontsize=10.5)
    ax1.set_xlim(-85, 85)
    ax1.set_ylim(-0.5, 12)
    ax1.grid(True, ls=':', color='gray', alpha=0.5)
    ax1.legend(loc='upper center', fontsize=8.5)

    mu_signal = np.linspace(-0.5, 4.0, 300)
    mu_hat = -0.2
    chi2_unconstrained = (mu_signal - mu_hat)**2 / 1.0
    chi2_constrained = np.copy(chi2_unconstrained)
    chi2_constrained[mu_signal >= 0] -= np.min(chi2_unconstrained[mu_signal >= 0])
    chi2_constrained[mu_signal < 0] = 0.0

    ax2.plot(mu_signal, chi2_unconstrained, color='#d62728', ls='--', lw=1.5, label=r'Unconstrained Parabola ($\widehat{\mu} < 0$)')
    ax2.plot(mu_signal[mu_signal >= 0], chi2_constrained[mu_signal >= 0], color='#2ca02c', lw=2.2, label=r'Physical Boundary Profile ($\mu \geq 0$)')

    ax2.axvline(0, color='black', lw=1.2, ls='-')
    ax2.text(0.05, 8.5, r'Physical Boundary ($\mu \geq 0$)', fontsize=8.5, rotation=90, va='top')
    ax2.axhline(1.0, color='gray', ls=':', lw=1.0)
    ax2.axhline(2.71, color='gray', ls=':', lw=1.0)
    ax2.text(1.8, 2.9, r'Constrained Profile $\Delta\chi^2 = 2.71$', fontsize=8.5, color='gray')

    ax2.set_xlabel(r'Signal Parameter $\mu \propto B(XL)$ (Arbitrary Units)', fontsize=10)
    ax2.set_ylabel(r'$\Delta\chi^2(\mu)$', fontsize=10)
    ax2.set_title(r'(b) Illustrative Profile Likelihood near Boundary', fontsize=10.5)
    ax2.set_xlim(-0.5, 3.5)
    ax2.set_ylim(-0.2, 9.5)
    ax2.grid(True, ls=':', color='gray', alpha=0.5)
    ax2.legend(loc='upper right', fontsize=8.5)

    fig.tight_layout()

    svg_path = os.path.join(img_dir, 'inference-profile-likelihood-boundary.svg')
    pdf_path = os.path.join(img_dir, 'inference-profile-likelihood-boundary.pdf')

    fig.savefig(svg_path, format='svg')
    fig.savefig(pdf_path, format='pdf')
    plt.close(fig)

    print(f"Generated {svg_path}")
    print(f"Generated {pdf_path}")

if __name__ == '__main__':
    main()
